import Router from 'koa-router';
import { api } from "../utils/fetch";
import { debug } from "../debug";
const router = new Router();

export const patch = function (ctx) {
	const entry = ctx.params[0], req = ctx.request, method = ctx.method;
	const headers = { platform: "ios" };
	["platform", "type", "x-auth-token"].forEach((elm) => { 
		headers[elm] = req.headers[elm];
	});
	let options = {
        qs: ctx.query,
        body: req.body,
        json: true,
        method,
        headers: headers
    };

    return { entry, options };
}

function *API(next){
	const { entry, options } = patch(this);

	const result = yield api(entry, options);
	this.body = result.body;
};

["get", "post", "put", "del"].forEach( function(elm, index) {
	router[elm]('/api/(.*)', API);
});

export default router;