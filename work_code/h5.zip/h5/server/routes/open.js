import Router from 'koa-router';
import { open } from "../utils";
import { debug } from "../debug";

const router = new Router();

function *openApi() {
	const url = this.params[0], req = this.request, method = this.method;

	let options = {
        qs: this.query,
        body: req.body,
        json: true,
        method
    };

	const res = yield open(url, options);

	this.body = res.body;
}

["get", "post", "put", "del"].forEach( function(elm, index) {
	router[elm]('/open/(.*)', openApi);
});

export default router;
