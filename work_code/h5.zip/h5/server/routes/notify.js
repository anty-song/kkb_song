import Router from 'koa-router';
import { api } from "../utils/fetch";
import { open } from "../utils";
import logger, { debug } from "../debug";
import _ from "lodash";

const status_code = {
	"s20": "PROCESSING",
	"s30": "PAID",
	"s40": "FAILED",
	"s50": "REFUNDING",
	"s60": "REFUNDED"
};

const router = new Router({
	prefix: '/notify'
});

router.get("/pay", function* () {
	this.body = "/pay";
});

router.post("/pay", function* () {
	const req = this.request;
	const orderId = req.body && req.body.thirdOrderNo;

	debug("异步回调: ", req.body, orderId);

	if (orderId) {
		const url = "order/get";

		const { body } = yield open(url, { qs: {thirdOrderNo: orderId}, json: true });
		debug("异步查询结果: ", body);
		try {
			const { data, status } = body;
			if (status && data) {
				// 调用接口
				const load = _.pick(data, ["amount", "status", "pingppChargeId", "subject", "thirdOrderNo", "channel"]);
				load.status = status_code['s'+load.status];
				const result = yield api("accounting/notify", {
					method: "POST",
					json: true,
					body: load
				})

				const { error_code } = result.body;
				if (error_code !== 0) {
					this.status = 400;
				}
				logger.info("异步同步: ", result.body, this.status, error_code);
				this.body = result.body;
				return
			} 
		} catch(e) {
			console.log("异常: ", e);
			logger.error("异步异常: ", e, body);
		}
	}

	this.body = "fail";
	this.status = 400;
})

export default router;