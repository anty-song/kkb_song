import open from './open';
import api from './api';
import notify from './notify';

module.exports = function(app) {
	app.use(function* (next) {
		if (this.method === 'HEAD') {
			this.status = 200;
		} else {
			yield next;
		}
	});

	app.use(api.routes());
	app.use(open.routes());
	app.use(notify.routes());
};