import koa from "koa";
import serve from "koa-static-server";
import router from "koa-router";
import send from "koa-send";
import path from "path";
import config from "./config";
import historyApiFallback from "koa-history-api-fallback";
import { debug } from "./debug";
import IP from '../build/lib/getIp';
import opn from 'opn';
const app = koa();

// 加载中间件
require("./middlewares")(app);

// 路由
require("./routes")(app);

app.use(historyApiFallback({
	verbose: false,
	index: "/"
}));

debug(`当前环境: ${app.env}`)
// 添加 webpack dev server
if (app.env === "development") {
	require("./middlewares/debug")(app);
	app.use(serve({ rootDir: "static", index: "index.html" }));
} else {
	app.use(serve({ rootDir: "dist/static" }));
	app.use(serve({ rootDir: "dist", index: "index.html" }));
}

app.listen(config.port, () =>{
        var ip = IP.getIp();
        // 如果未联网则使用本机回环地址：127.0.0.1
        ip = ip || 'localhost';
        var uri = 'http://' + ip + ':' + config.port;
        opn(uri);
        debug(`应用启动...` + uri, app.env, process.env.NODE_ENV);
});