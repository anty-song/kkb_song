var bodyParser = require('koa-body');
var koaBody = require('koa-body');

module.exports = function (app) {
	// query string
	require('koa-qs')(app, 'extended');
	app.use(koaBody());

	// 添加爬虫日志
}
