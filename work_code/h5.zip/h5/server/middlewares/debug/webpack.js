import dev from 'webpack-dev-middleware';
import hot from 'webpack-hot-middleware';

function transfrom(req, res, next) {
	var originalEnd = res.end;

	return function (done) {
		res.end = function () {
			originalEnd.apply(this, arguments);
			done(null, 0);
		};
		next(req, res, function () {
			done(null, 1);
		});
	};
}

/**
 * dev server
 */
export const devMiddleware = (compiler, opts) => {
	const middleware = dev(compiler, opts);

	return function *(next) {
		var ctx = this;
		ctx.webpack = dev;
		var req = this.req;
		var runNext = yield transfrom(req, {
			end: function (content) {
				ctx.body = content;
			},
			setHeader: function () {
				ctx.set.apply(ctx, arguments);
			}
		}, middleware);

		if (runNext) {
			yield * next;
		}
	}
}

/**
 * hot reload 
 */
export const hotMiddleware = (compiler, opts) => {
	const middleware = hot(compiler, opts)
	return function *(next) {
		var nextStep = yield transfrom(this.req,  this.res, middleware);
        if (nextStep && next) {
            yield* next;
        }
	}
}
