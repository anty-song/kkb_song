import { devMiddleware, hotMiddleware } from "./webpack";
var webpack = require("webpack");
var webpackConfig = require('../../../build/webpack.dev.conf');
var debug = require("debug")("gxb");

const devConfig = {
	noInfo: false,
	quiet: false,
	publicPath: webpackConfig.output.publicPath,
	hot: true,
	lazy: false,
	historyApiFallback: true,
	// watch options (only lazy: false)
	watchOptions: {
		aggregateTimeout: 300,
		poll: true
	},
	stats: {
		colors: true,
		chunks: false,
		chunkModules: false
	}
}

module.exports = function (app) {
	const compiler = webpack(webpackConfig);

	debug("设置 webpack ----------------------");
	app.use(devMiddleware(compiler, devConfig));
	app.use(hotMiddleware(compiler));

};
