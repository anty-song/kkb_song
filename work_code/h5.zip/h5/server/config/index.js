/**
 * 根据不同环境返回配置
 */

// import development from "./development.json";
// import pre from "./pre.json";
// import stage from "./stage.json";
// import production from "./production.json";

// export const config = {
// 	development,
// 	pre,
// 	stage,
// 	production
// }

export const env = function () {
	const type = process.env.NODE_ENV || 'development';
	try {
		return require(`./${type}`);
	} catch(e) {
		return {};
	}
}

export default env();