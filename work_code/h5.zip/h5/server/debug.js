import config from "./config";
const winston = require("winston");

require('winston-daily-rotate-file');

var transports = {
        development: [new (winston.transports.Console)({
                prettyPrint: true,
                colorize: true,
            }),
            new (winston.transports.DailyRotateFile)({ 
                name: 'file',
                prepend: true,
                maxFiles: 10,
                filename: 'logs/dev.log' 
            })
        ],
        dev: [new (winston.transports.Console)({
                prettyPrint: true,
                colorize: true,
            }),
            new (winston.transports.DailyRotateFile)({ 
                name: 'file',
                prepend: true,
                maxFiles: 10,
                filename: 'logs/dev.log' 
            })
        ],
        stage: [
            new (winston.transports.Console)({
                prettyPrint: true,
                colorize: true,
            }),
            new (winston.transports.DailyRotateFile)({ 
                name: 'file',
                prepend: true,
                maxFiles: 60,
                filename: 'logs/stage.log' 
            })
        ],
        pre: [
            new (winston.transports.Console)({
                prettyPrint: true,
                colorize: true,
            }),
            new (winston.transports.DailyRotateFile)({ 
                name: 'file',
                prepend: true,
                maxFiles: 60,
                filename: 'logs/pre.log' 
            })
        ],
        production: [
            new (winston.transports.DailyRotateFile)({
                name: 'info-file',
                filename: 'logs/filelog-info.log',
                prepend: true,
                maxFiles: 60,
                level: 'info'
            }),
            new (winston.transports.DailyRotateFile)({
                name: 'error-file',
                filename: 'logs/filelog-error.log',
                prepend: true,
                maxFiles: 60,
                level: 'error'
            })
        ]
    },
    logLevel = config.logLevel || 'debug',
    env = process.env.NODE_ENV || 'development';

var logger = new (winston.Logger)({
    exitOnError: false,
    level: logLevel,
    transports: transports[env]
});

export const debug = logger.debug;
export const info = logger.info;
export const error = logger.error;
export default logger;
