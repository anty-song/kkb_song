import {
	fetch,
	api
} from "./fetch";
import crypto from "crypto";
import querystring from "querystring";
import { debug } from "../debug";
import conf from "../config";

const config = conf.open;

/**
 * 参数签名
 * @param  {obj} 	params  	需要加密参数
 * @param  {bool} 	needParse   是否需要先 parse 为对象
 * @return {string}        	结果字符串
 */
export const sign = (params, needParse) => {
	params = needParse ? JSON.parse(params) : params;
	params.appKey = config.appKey;
	return getSign(config.appSecret, stringifyData(params));
}

const getSign = function (secret, query) {
	query = encodeURIComponent(query);
	const str = crypto.createHmac('sha1', secret)
		.update(query)
		.digest("base64");
	return str;
}

export const stringifyData = function (data, urlencode) {
	var hasOwn = {}.hasOwnProperty;
	if (typeof urlencode == 'undefined') {
		urlencode = false;
	}
	var output = [];
	for (var i in data) {
		if (!hasOwn.call(data, i) || typeof data[i] === 'function') {
			continue;
		}
		if (i == 'sign') {
			continue;
		}
		output.push(i + '=' +
			(urlencode ? encodeURIComponent(data[i]) : data[i]));
	}
	return output.sort().join('&');
}

/**
 * 请求开放平台接口
 * @param  {string}     url  接口 URL
 * @param  {obj}        opts 请求参数
 * @return {generatror}      generator 对象
 */
export const open = (url, opts) => {
	opts = Object.assign({ method: "GET" }, opts);
	if (opts.method == "GET") {
		opts.qs.sign = sign(opts.qs);
	}

	// 修改 POST 请求 header
	if (opts.method == 'POST') {
		opts.body.sign = sign(opts.body);
		opts.qs = Object.assign({}, opts.qs, opts.body);
	}

	return fetch (url, opts);
}