import request from "koa-request";
import config from "../config";
import logger, { debug } from "../debug";

const env = process.env.NODE_ENV;

// 开课吧 api 地址
const api_host = config.api;

// 高校邦 api 地址
const open_api = "http://open.gaoxiaobang.com/";

/**
 * 高校邦开放 api 访问方法
 */
export const fetch  = function (url, opts) {
	opts.url = open_api + url;
	logger.info("开放接口: ", opts.method, opts.url, opts.qs, opts.headers);
	Object.assign(opts, { forever: true, timeout: 10000 });
	return request(opts);
} 

/**
 * 开课吧带 header 访问方法
 */
export const api = function (url, opts) {
	opts.url = api_host + url;
	logger.info("api: ", opts.method, opts.url, opts.qs, opts.headers, opts.body);
	Object.assign(opts, { forever: true, timeout: 10000 });
	return request(opts);
}