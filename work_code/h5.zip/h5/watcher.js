'use strict';

let pm2 = require('pm2'),
	pkg = require('./package.json');
	
pm2.connect(function(err) {
	if (err) {
		return 
	}	

	reload_process(pkg.name);
})

function reload_process (name, cb) {
	console.log("reloading from watcher...");
	// 重启主要服务
	// pm2.gracefulReload(name, function(){
	// 	console.log("reloading from watcher...");
	// });

	// 其他脚本
}
