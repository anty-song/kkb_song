module.exports = {
	"root": true,
	"env": {
		"es6": true,
		"browser": true,
		"node": true
	},
	"parserOptions": {
        "ecmaVersion": 6,
        "sourceType": "module",
        "ecmaFeatures": {
            "jsx": false,
            "experimentalObjectRestSpread": true
        }
    },
    "globals": {
        "window": true,
        "PRODUCTION": true
    },
    "extends": [
        "eslint:recommended",
        "vue"
    ],
    "rules": {
        // enable additional rules
        "indent": ["warn", 'tab', { "SwitchCase": 1 }],
        "linebreak-style": ["warn", "unix"],
        "quotes": ["warn", "double"],
        "semi": ["warn", "always"],
        "eqeqeq": "error",
        // override default options for rules from base configurations
        "comma-dangle": ["off", "always"],
        "no-cond-assign": ["error", "always"],
        "no-multi-spaces": ["off"],
        "spaced-comment": ["off"],
        "generator-star-spacing": ["off"],
        // disable rules from base configurations
        "no-console": "off",
        "eol-last": ["warn"]
    }
}