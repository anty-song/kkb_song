const request = require("superagent");
import store from "./vuex/store";

function api(url, method, data, options) {
    const opts = Object.assign({
        "type": "json",
        "X-Requested-With": "XMLHttpRequest",
        "Platform": "h5",
        "X-Auth-Token": store.state.user.token
    }, options);

    opts.token = store.state.user.token || undefined;

    return new Promise((resolve, reject) => {
        request[method](url)
            .send(data)
            .set(opts)
            .timeout(10000)
            .end((err, res) => {
                if (err) {
                    return reject(err);
                }
                resolve(JSON.parse(res.text));
            });
    }).then((res) => {
        return res;
    }, (err) => {
        return { err };
    });
}

export function get(url, data, opts) {
    return api(url, "get", null, opts);
}

export function post(url, data, opts) {
    return api(url, "post", data, opts);
}

export function h5(url, data, opts = {}) {
    Object.assign(opts, {
        Platform: "h5"
    });

    const m = {};
    ["get", "post"].forEach((elm) => {
        m[elm] = () => {
            return api(url, elm, data, opts);
        };
    });

    return m;
}