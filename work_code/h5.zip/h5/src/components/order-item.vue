<template>
	<div class="pd20">
		<div class="order-item" v-for="order in orders">
			<div class="course-info clearfix">
				<img :src="order.c_pic" alt="" class="cover">
				<p>{{ order.o_name }}</p>
				<p class="small">￥{{ order.c_price }}</p>
			</div>
			<div class="price-info">
				<div class="clearfix">
					<div class="price">
						<p>
							<span>实付款：<span class="red">￥{{ order.o_price }}</span></span>
						</p>
						<p class="small" v-if="order.cp_price != 0">
							已优惠￥{{ order.cp_price }}
						</p>
					</div>
					<a class="btn-danger btn" @click="view_order(order);">去付款</a>
				</div>
			</div>
		</div>
	</div>
</template>

<style lang="scss">
	@import "../assets/sass/variables.scss";
	.pd20 {
		padding-bottom: 0.2rem;
	}
	.order-item {
		background-color: #fff;
		margin-top: 0.2rem;
		padding: 0.2rem 0.3rem;

		.course-info {
			.cover {
				width: 1.9rem;
				height: 1.07rem;
				float: left;
				margin-right: 0.2rem;
			}

			p {
				font-size: 0.28rem;
				color: $grey;

				&.small {
					font-size: 0.28rem;
					color: $light-gray;
					margin-top: 0.25rem;
				}
			}
			margin-bottom: 0.2rem;
		}

		.price-info {
			position: relative;
			padding-top: 0.2rem;
			color: $light-gray;
			font-size: 0.28rem;
			margin-right: -0.3rem;

			&:before {
				content: "";
				position: absolute;
				top: 0;
				left: 0;
				width: 100%;
				border-top: 1px solid #eee;
				transform: scaleY(0.5);
			}

			.price {
				display: inline-block;

				p.small {
					font-size: 0.25rem;
				}
			}

			.btn {
				position: absolute;
				right: 0.3rem;
				top: 50%;
				font-size: 0.26rem;
				margin-top: -0.16rem;
			}
		}
	}
</style>

<script>
	import { router } from "../router";

	export default {
		name: "Order",
		props: ["orders"],
		methods: {
			view_order (order) {
				this.$store.dispatch("UPDATE_ORDER", {
					kid: order.o_id,
					name: order.o_name,
					amount: order.o_price,
					cp_price: order.cp_price
				});
				router.push({ name: "pay", params: { id: order.o_id }});
			}
		}
	};
</script>