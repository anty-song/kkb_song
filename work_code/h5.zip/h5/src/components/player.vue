<template>
	<div class="player-container">
		<div class="player">
			<div class="player-box"></div>
			<div class="section-info">
				<p class="title">{{chapter.title}}</p>
				<p>{{chapter.description}}</p>
				<p class="tutor hair-line"><img class="icon" src="/img/player/ic_mycourse_zx_teacher@3x.png">
					{{ tutors }}
				</p>
			</div>
		</div>
		<slot></slot>
	</div>
</template>

<style lang="scss">
	.player {
		position: relative;

		.player-box {
			height: 3.6rem;
			background-color: #1F1C1C;
		}

		.section-info {
			padding: 0.24rem 0.3rem 0;
			background-color: #fff;
			color: #B8B1B2;
			font-size: 0.26rem;
			
			.title {
				color: #3F3939;
				font-size: 0.3rem;
				margin-bottom: 0.12rem;
			}

			.tutor {
				margin: 0.3rem -0.3rem 0;
				padding: 0.26rem 0.3rem;
				background-repeat: repeat-x;
				background-position: top center;

				.icon {
					width: 0.3rem;
					height: 0.3rem;
					vertical-align: middle;
					margin-right: 0.13rem;
				}
			}
		}
	}

</style>

<script>
	import bus from "../lib/event";

	export default {
		props: ["vid"],
		data () {
			return {
				player: null
			};
		},
		computed: {
			chapter () {
				return this.$store.state.current.chapter;
			},
			tutors () {
				const tutors = this.chapter.lectures_mini || [];
				return tutors.join(" ");
			}
		},
		watch: {
			vid (id) {
				const sessionId = this.$store.state.user.openid;
				this.play(id, sessionId);
			}
		},
		mounted () {
			bus.$on("stopVideo", () => {
				if (this.player) {
					try {
						this.player.j2s_stopVideo();
					} catch (e) {
						window.console && console.log(e);
					}
				}
			});
		},
		methods: {
			play (id, sessionId) {
				if (this.player) {
					this.player.changeVid(id);
				} else {
					const selector = ".player-box";
					const height = document.querySelector(selector).clientHeight;
					this.player = window.polyvObject(selector)
						.videoPlayer({
							height,
							"vid": id,
							"session_id": sessionId
						});
				}
				try {
					this.player.j2s_resumeVideo();
				} catch (e) {
					window.console && console.log(e);
				}
			}
		}
	};
</script>