<template>
	<div class="flex courses">
		<div v-for="course in courses" class="course-item" :class="{small: small}" @click="view(course)">
			<img :src="small ? course.pic : course.bigPic" :title="course.name" :alt="course.name">
			<span class="category">{{course.category}}</span>
			<div class="info">
				<p class="name">
					{{course.name}}
					<span v-if="!small" class="salary">{{course.salaryRange}}</span>
				</p>
				<p class="sub">
					<span>{{course.hours}} 课时</span>
					<span>{{course.longtime}} 分钟</span>
				</p>
			</div>
		</div>
	</div>
</template>

<style lang="scss">
.course-item {
	border-radius: 0.04rem;
	overflow: hidden;
}
</style>

<script>
import { router } from "../router";

export default {
	name: "course",
	props: ["courses", "small"],
	methods: {
		view(course) {
			router.push({ name: "course", params: { id: course.courseid } });
		}
	}
};
</script>