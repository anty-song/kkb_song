import Vue from "vue";
import Price from "./price";

/**
 * 动态组建，主要用于生成 课程 h5 详情
 * 替换 { price($courseId, true) } => <price></price>
 */
export const tpl = {
	courseInfo: {
		name: "CourseInfo",
		components: {
			price: Price,
		}
	}
};

const kfUrl = "http://kefu8.kuaishang.com.cn/bs/im.htm?cas=30989___418723&fi=35187&ism=1&ref=H5&sText=";
const downloadUrl = "http://a.app.qq.com/o/simple.jsp?pkgname=com.bufanbudao.kaikeba";

export const make = (component, template, data) => {
	template = template && template
		.replace(/\{price\(\$course[iI]d, true\)\}/, "<price :course='" + data + "'></price>")
		.replace(/\{consult\('([\w_]+)[\w,\s'$]+\)\}/gm, kfUrl + "$1")
		.replace(/\{appDownload\([\w,\s'$]+\)\}/gm, downloadUrl);

	const settings = Object.assign({}, tpl[component], { template: `<div class="detail-wrap">${template}</div>` });
	const Comp = Vue.extend(settings);

	return new Comp();
};
