<template>
	<div>
		<div class="signup">
	        <h2 class="block-tit">我要报名</h2>
	        <!-- 两套学习方案， -->
	        <p class="center block-des">真正懂你的<span class="strong">{{ info.name }}</span>就业班</p>
	        <div class="item sign">
	            <div class="header">
	                <strong class="iblock price">￥{{ info.occupy_price_spec }}</strong>
	                <span class="iblock tip">全款特惠</span>
	            </div>
	            <div class="body">
	                <p class="remark">
	                    权威保障高薪就业<br/>
	                    录播＋直播＋名师实训（总价10688）
	                </p>
	                <a class="opt" data-target="sign_up"
	                  @click="signup()" >
	                    <span class="iblock text">即刻报名</span>
	                    <span class="iblock icon-box"><img src="/public/images/ic_coursedetail_btnjt1@3x.png"/></span>
	                </a>
	            </div>
	            <img class="status" src="/public/images/img_coursedetail_yhbq@3x.png"/>
	        </div>
	    </div>
	</div>
</template>

<style lang="scss">
	.signup {
		.header {
			background-image: url(/img/signup/img_coursedetail_yhbg@3x.png);
		    background-position: center top;
		    background-repeat: no-repeat;
		    background-size: cover;
		}
	}
</style>

<script>
	import store from "../vuex/store";
	import { router } from "../router";

	export default {
		name: "Price",
		props: ["course"],
		computed: {
			info () {
				return store.state.current.info;
			}
		},
		methods: {
			signup () {
				const st = store.state.current.signup_status || {};
				const ci = this.course;
				const bought = st.buytype === 1;
				if (bought) {
					router.push({ name: "alert", query: { result: "bought" }});
				} else {
					router.push({ name: "signup", params: { course: ci }});
				}
			}
		}
	};
</script>