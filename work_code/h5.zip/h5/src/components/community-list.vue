<template>
	<div class="communitylist">
		<ul>
			<li v-for="item in communitylist">
				<a :href="'kkb://communityDetail/'+item.flag+'/'+item.id+'/'">
					<div class="author">
						<span class="avatar" v-bind:style="{'background-image': 'url(' +item.avatar + ')'}"></span>
						<span class="name">{{item.nickname}}</span>
					</div>
					<div class="content">
						<div class="c-left">
							<div class="cover_image" v-bind:style="{'background-image': 'url(' +item.cover_image + ')'}"></div>
						</div>
						<div class="c-right">
							<p class="title">{{item.title}}</p>
							<p class="introduce">{{item.introduce}}</p>
							<div class="article-data">
								<span class="view_count">{{item.view_count_false}}</span>
								<span class="like_count">{{item.like_count}}</span>
								<span class="favorite_count">{{item.favorite_count}}</span>
							</div>
						</div>
					</div>
				</a>
			</li>
		</ul>
	</div>
</template>

<style lang="scss">

</style>

<script>
export default {
	name: "communitylist",
	props: ["communitylist"],
	methods: {

	}
};
</script>