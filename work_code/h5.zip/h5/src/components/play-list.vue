<template>
	<div class="pane padding">
		<ul class="play-list">
			<li v-for="(node, i) in nodes" class="item" :class="{
				active: node.nodeid === playing.nodeid,
				excs: node.type === 'exercise'
			}"
			@click="study(node, node.type, i);">
				{{node.title}}
			</li>
		</ul>
	</div>
</template>

<style lang="scss">
	@import "../assets/sass/variables.scss";

	.pane {
		padding-top: 0;
		padding-bottom: 0;
	}
	.play-list {
		font-size: 0.24rem;

		.item {
			position: relative;
			color: #666;
			line-height: 0.36rem;
			padding: 0.27rem 0.3rem 0.27rem 0;
			margin-left: 0.5rem;
			margin-right: -0.3rem;
			// margin-left: 20px;

			&:after {
				content: "";
				position: absolute;
				top: 0;
				left: 0;
				width: 100%;
				border-top: 1px solid #eee;
				transform: scaleY(0.5);
			}

			&:first-child:after {
				border-top: none;
			}

			&:before {
				content: '';
				display: inline-block;
				margin-right: 0.13rem;
				vertical-align: middle;
				margin-top: -1px;
				width: 0.3rem;
				height: 0.3rem;
				background: url('/img/player/list-icon.png') top center no-repeat;
				background-size: 100% auto;
				margin-left: -0.5rem;
			}

			&.excs:before {
				background-position: 0px -0.9rem;
			}

			&.active {
				color: $blue;

				&:before {
					background-position: 0px -0.6rem;
				}

				&.excs:before {
					background-position: 0px -1.5rem;
				}
			}
		}
	}
</style>

<script >
	import bus from "../lib/event";

	export default {
		name: "PlayList",
		props: ["nodes", "start"],
		data () {
			return {
				course_id: this.$route.params.course,
				playing: {}
			};
		},
		watch: {
			start (newValue) {
				this.study(newValue, newValue.type, 0);
			}
		},
		methods: {
			study (node, type, index) {
				var nodeId = node.nodeid;
				var isFree = !!node.free || (index === 0 && type !== "practise");
				var isLogin = this.$store.state.user.uid !== undefined;
				var bought = this.$store.state.current.signup_status.buytype !== 0;

				bus.$emit("stopVideo");
				this.playing = node;
				if (isFree || (isLogin && bought)) {
					if (type === "video") {
						this.$emit("play", node);
					} else if (type === "exercise") {
						var excsUrl = location.protocol + "//" + location.host.replace("h5", "www") + "/app/exercise/" + this.course_id +
						"?platform=h5&token=" + this.$store.state.user.token + "&nodeid=" + nodeId;
						location.href = excsUrl;
					}
				} else {
					if (!isLogin) {
						this.$emit("mask", "not_buy");
					} else {
						if (!bought) {
							this.$emit("mask", "not_buy");
						}
					}
				}
			}
		}
	};
</script>
