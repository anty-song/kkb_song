<template>
	<div class="singleCourse">
		<ul>
			<li v-for="item in single_course">
				<a :href="'kkb://coursemain/'+item.id">
					<div class="cover-img" v-bind:style="{'background-image': 'url(' +item.picApp + ')'}"></div>
					<div class="content">
						<p class="title">{{item.title}}</p>
						<p class="teacher">
							<span class="teacher-avator" v-bind:style="{'background-image': 'url(' +item.avatar + ')'}"></span>
							<span class="teacher-name">{{item.teacherName}}</span>
						</p>
						<p class="study">
							<span class="study-number">{{item.studyNum}}人学习</span>
							<span v-show="reviewStatus==1" class="price">{{item.price=="0.00"?"免费":"¥"+item.price}}</span>
						</p>
					</div>
				</a>
			</li>
		</ul>
	</div>
</template>

<style lang="scss">
.singleCourse {
	li {
		margin: 0 auto;
		padding: .3rem .2rem;
		padding-top: 0;
		display: flex;
		a {
			width: 100%;
			display: block;
			overflow: hidden;
			padding: .2rem;
			background: #fff;
			.cover-img {
				float: left;
				overflow: hidden;
				width: 49%;
				height: 1.84rem;
				background-size: 100% 100%;
			}
			.content {
				float: left;
				overflow: hidden;
				width: 51%;
				padding: .16rem .26rem;
				background-color: #fff;
				padding-bottom: 0;
				.title {
					font-size: .3rem;
					color: #333;
					display: -webkit-box;
					-webkit-box-orient: vertical;
					-webkit-line-clamp: 1;
					overflow: hidden;
					padding-bottom: .1rem;
				}
				.teacher {
					font-size: .26rem;
					color: #848F98;
					padding-bottom: .15rem;
					border-bottom: 1px solid #F5F5F5;
					.teacher-avator {
						display: inline-block;
						vertical-align: middle;
						width: .5rem;
						height: .5rem;
						border-radius: 50%;
						background-size: 100% 100%;
					}
					.teacher-name {
						display: inline-block;
						vertical-align: middle;
					}
				}
				.study {
					padding-top: .1rem;
					font-size: .24rem;
					.study-number {
						color: #848F98;
					}
					.price {
						float: right;
						color: #F17676;
					}
				}
			}
		}
	}
	li:last-child {
		padding-bottom: 0;
	}
}
</style>

<script>
export default {
	name: "singleCourse",
	data() {
		return {
			reviewStatus: this.$route.query.reviewStatus
		}
	},
	props: ["single_course"],
	methods: {

	}
};
</script>