import Signup from "./signup_success";
import PaymentFail from "./payment_fail";
import Bought from "./bought";

export {
	Signup as success,
	PaymentFail as fail,
	Bought as bought
};
