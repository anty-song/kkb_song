<template>
	<div class="failed">
		<h1><img src="/img/signup/img_bm_ts_sb@3x.png" class="icon">支付失败</h1>
		<p class="small">抱歉，您的订单没有支付成功</p>
		<p>可能是以下原因导致您支付失败，您可以对照进行问题排查，也可以咨询或呼叫课程MM。</p>
		<p>1.支付宝或是网银设置了交易金额上限，建议您登陆支付宝或网上银行提高上限额度。</p>
		<p>2.支付宝或是网银页面提示“页面过期、超时、错误”等问题时，建议您稍后重新支付。</p>
		
		<div class="flex links">
			<router-link :to="{name: 'orders'}" 
			class="half pull-left mint-button mint-button--default">查看未完成订单</router-link>
			<router-link :to="{name: 'pay', params: {id: orderId}}" 
			class="half pull-right  mint-button mint-button--danger">重新支付</router-link>
		</div>
	</div>
</template>

<style>
	.links {
		justify-content: space-between;
		overflow: initial;
	}
</style>

<script>
	import { getOrderId } from "../../utils";
	export default {
		computed: {
			orderId () {
				return getOrderId(this.$route.query.thirdOrderNo);
			}
		}
	};
</script>
