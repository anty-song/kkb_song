<template>
	<div>
		<h1><img src="/img/signup/img_bm_ts_cg@3x.png" class="icon">报名成功</h1>
		<h4 class="text-center">欢迎您加入开课吧({{ course_name }})</h4>
		<img src="/img/signup/img_bm_cg@3x.png" class="result-img">
		<p class="hint">
			完整的学习体验需要下载开课吧APP使用，开课吧APP初始登录密码请注意查收手机短信。
		</p>
		<a href="http://a.app.qq.com/o/simple.jsp?pkgname=com.bufanbudao.kaikeba" 
		class="mint-button btn-block mint-button--primary" target="_blank">下载开课吧APP</a>
	</div>
</template>

<script>
	import { getOrderId } from "../../utils";

	export default {
		beforeMount () {
			this.$store
				.dispatch("GET_ORDER_INFO", getOrderId(this.$route.query.thirdOrderNo));
		},
		computed: {
			course_name () {
				const name = this.$store.state.order.name;
				return name.replace(/[-\s]*就业全款/, "-就业班");
			}
		}
	};
</script>
