<template>
	<div class="error">
		<h1><img src="/img/signup/img_bm_ts_sb@3x.png" class="icon">报名失败</h1>
		<h4>亲，您已经买过该课程啦，钱多也不要任性哦。好好把这门课程学好吧，加油！</h4>
		<img src="/img/signup/img_bm_fail@3x.png" class="result-img">
		<a href="http://a.app.qq.com/o/simple.jsp?pkgname=com.bufanbudao.kaikeba" 
		class="mint-button mint-button--default half mr30" target="_blank">下载开课吧APP</a>
		<router-link :to="{name: 'course', params: {id: course_id}}" class="mint-button mint-button--primary half">继续学习</router-link>
	</div>
</template>

<script>
	export default {
		computed: {
			course_id () {
				return this.$store.state.current.course_id;
			}
		}
	};
</script>
