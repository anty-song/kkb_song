<template>
	<div>
		<div class="basics">
		    <h2 class="tit">{{ info.name }}</h2>
		    <p class="iblock half">
		        <span class="tag">学习周期 ：</span>
		        <span class="des red">{{ info.period }}天</span>
		    </p>
		    <p>
		    	<span class="tag">所属行业 ：{{ info.category }}</span>
		    	<span class="des"></span>
			</p>
		    <p>
		    	<span class="tag">课程讲师 ：</span>
		    	<span class="des" v-for="tutor in tutors">
		        	<span class="mr20">{{ tutor }}</span>
		        </span>
		    </p>
		    <p v-show="reviewStatus==1">
		    	<span class="tag">保就业班 ：</span>
		    	<span class="des">
		    		<span class="red">全款特惠￥{{ info.occupy_price_spec }}
		    		</span><br/>
		    		<span class="price">原价
		    			<span class="del">￥{{ info.occupy_price }}</span>
					</span>
				</span>
			</p>
		</div>
		<!-- 课程描述 -->
		<div class="des-box">
		    <h3 class="box-tit"><img src="/public/images/ic_coursedetail_ms@2x.png">课程描述</h3>
		    <div class="des">
		        <p class="detail">{{ info.desc }}</p>
		        <span class="tag hairlines" v-if="info.custom1">{{ info.custom1 }}</span>
		        <span class="tag hairlines" v-if="info.custom2">{{ info.custom2 }}</span>
		        <span class="tag hairlines" v-if="info.custom3">{{ info.custom3 }}</span>
		    </div>
		</div>
		<!-- 课程大纲 -->
		<div class="outline-box">
		    <h3 class="box-tit"><img src="/public/images/ic_coursedetail_dg@2x.png"><span>课程大纲</span>
		    </h3>
		    <template v-for="(section, $i) in sections">
		    	<div class="stage-box">
		            <h4 class="stage-tit">
		                <span class="iblock tag hairlines">
		                    <span class="iblock text">阶段 {{ $i+1 }}</span>
		                </span>{{ section.title }}
		            </h4>
					<!--kkb://coursepractise/:courseid/:subid/:nodeid/:practiseid  -->
		            <template v-for="(sub, $j) in section.subs">
		            	<a v-if="sub.type > 0"
							:href="'kkb://coursepractise/'+course_id+'/'+sub.subid+'/'+sub.nodeid+'/'+sub.practiseid+'/'"
						   class="stage-item" :class="{last: $j === section.subs.length - 1}">
		                    <div class="pic-box">
		                        <img class="pic" :src="sub.pic" />
		                    </div>
		                    <div class="info">
		                        <p class="tit">{{ ($i+1) + '-' + ($j+1) + ' ' + sub.title }}</p>
		                        <span class="tag">{{ sub.type > 0 ? '实训任务' : '课程学习' }}</span>
		                    </div>
		                </a>
						<a v-if="sub.type <= 0"
							:href="'kkb://coursestudy/'+course_id+'/'+sub.subid+'/'"
						   class="stage-item" :class="{last: $j === section.subs.length - 1}">
		                    <div class="pic-box">
		                        <img class="pic" :src="sub.pic" />
		                    </div>
		                    <div class="info">
		                        <p class="tit">{{ ($i+1) + '-' + ($j+1) + ' ' + sub.title }}</p>
		                        <span class="tag">{{ sub.type > 0 ? '实训任务' : '课程学习' }}</span>
		                    </div>
		                </a>
		            </template>
		        </div>
		    </template>
		</div>
	</div>
</template>

<script>
	import { Toast as toast } from "mint-ui";
	import { router } from "../router";

	export default {
		data () {
			return {
				course_id: this.course.course_id,
				reviewStatus: this.$route.query.reviewStatus
			};
		},
		computed: {
			sections () {
				return this.course.sections;
			},
			info () {
				return this.course.info;
			},
			tutors () {
				return this.course.tutors;
			}
		},
		methods: {
			show (node) {
				if (node.type === 1) {
					toast("实训课程请在开课吧App中查看");
					return;
				}
				router.push({ name: "section", params: {
					course: this.course_id, section: node.subid
				}});
			}
		},
		name: "courseSection",
		props: ["course"]
	};
</script>