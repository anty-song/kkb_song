<template>
	<div class="activity">
		<ul>
			<li v-for="item in activity">
				<a :href="'kkb://communityDetail/'+item.flag+'/'+item.id+'/'">
					<div class="cover-img" v-bind:style="{'background-image': 'url(' +item.cover_image + ')'}"></div>
					<div class="content">
						<p class="title">{{item.title}}</p>
						<p class="start-time">{{getLocalTime(item.start_time)}}</p>
					</div>
				</a>
			</li>
		</ul>
	</div>
</template>

<style lang="scss">
.activity {
	padding-bottom: 15px;
	li {
		margin: 0 auto;
		padding: .3rem .2rem;
		padding-top: 0;
		display: flex;
		a {
			padding: .2rem;
			background: #fff;
			width: 100%;
			display: block;
			overflow: hidden;
			.cover-img {
				width: 49%;
				height: 2.05rem;
				background-size: 100% 100%;
				float: left;
				overflow: hidden;
			}
			.content {
				position: relative;
				width: 51%;
				height: 2.05rem;
				padding: .16rem .24rem;
				background-color: #fff;
				float: left;
				overflow: hidden;
				.title {
					font-size: .3rem;
					color: #333;
					display: -webkit-box;
					-webkit-box-orient: vertical;
					-webkit-line-clamp: 2;
					overflow: hidden;
				}
				.start-time {
					position: absolute;
					bottom: 0;
					font-size: .24rem;
					color: #A6AFB5;
				}
			}
		}
	}
	li:last-child {
		padding-bottom: 0;
	}
}
</style>

<script>
export default {
	name: "activity",
	props: ["activity"],
	methods: {
		getLocalTime(ns) {
			var time = new Date(parseInt(ns) * 1000).toLocaleString().replace("GMT+8", "").split(":");
			var result = "";
			time.splice(2);
			result = time[0] + ":" + time[1];
			console.log(result)
			return result;
		}
	}
};
</script>