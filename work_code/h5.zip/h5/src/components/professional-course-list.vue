<template>
	<div class="professional">
		<ul>
			<li v-for="item in professional_course">
				<a :href="'kkb://course/'+item.id+'/'+item.title">
					<div class="cover-img" v-bind:style="{'background-image': 'url(' +item.picApp + ')'}"></div>
					<div class="content">
						<p class="title">{{item.title}}</p>
						<p class="slogan">{{item.oneWord}}</p>
					</div>
				</a>
			</li>
		</ul>
	</div>
</template>

<style lang="scss">
.professional {
	li {
		margin: 0 auto;
		padding: .3rem .2rem;
		padding-top: 0;
		display: flex;
		a {
			width: 100%;
			display: block;
			overflow: hidden;
			padding: .2rem;
			background: #fff;
			.cover-img {
				width: 49%;
				height: 1.84rem;
				background-size: 100% 100%;
				float: left;
				overflow: hidden;
			}
			.content {
				width: 51%;
				padding: .3rem .26rem;
				background-color: #fff;
				float: left;
				overflow: hidden;
				height: 1.5rem;
				margin-top: .18rem;
				padding-right: 0;
				.title {
					display: -webkit-box;
					-webkit-box-orient: vertical;
					-webkit-line-clamp: 2;
					overflow: hidden;
					font-size: .3rem;
					color: #333;
					padding-bottom: .1rem;
				}
				.slogan {
					display: -webkit-box;
					-webkit-box-orient: vertical;
					-webkit-line-clamp: 2;
					overflow: hidden;
					font-size: .24rem;
					color: #A6AFB5;
				}
			}
		}
	}
	li:last-child {
		padding-bottom: 0;
	}
}
</style>

<script>
export default {
	name: "professional_course",
	props: ["professional_course"],
	methods: {

	}
};
</script>