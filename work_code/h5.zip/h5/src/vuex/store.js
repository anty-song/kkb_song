import Vue from "vue";
import Vuex from "vuex";
import createLogger from "vuex/dist/logger";
import actions from "./actions";
import mutations from "./mutations";
const debug = process.env.NODE_ENV !== "production";

// 告诉 vue “使用” vuex
Vue.use(Vuex);

// 创建一个 object 存储应用启动时的状态
const state = {
    user: {
        name: "",
        trueName: "",
        mobile: "",
        qq: "",
        openid: "",
        uid: "",
        token: "",
        pending: ""
    },
    signup: {
        target: "在校生想顺利就业",
        basis: "完全是行业小白"
    },
    order: {
        kid: "",
        oid: "",
        name: "",
        channel: "",
        amount: "",
        cp_price: "",
        charge: {}
    },
    unpaid: [],
    sliders: [],
    courses: {},
    professional_course: {},
    single_course: {},
    cnavigation: {},
    community_list: {},
    exercise: {},
    activity: {},
    article_detail: {},
    auditorium_detail: {},
    activity_detail: {},
    course_detail_h5: "",
    current: {
        detail: "",
        sections: [],
        info: {},
        chapter: [],
        signup_status: {},
        course_id: 0
    }
};
// 通过 new Vuex.Store 结合初始 state 和 mutations，创建 store
// 这个 store 将和我们的 vue 应用链接起来
export default new Vuex.Store({
    state,
    mutations,
    actions,
    plugins: debug ? [createLogger()] : []
});