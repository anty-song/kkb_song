import {get, h5, post } from "../api";
import * as types from "./types";

const base = "/api";
const open = "/open";

export default {
    /**
     * 获取首页 banner 广告
     */
    GET_SLIDERS({ commit }) {
        const url = `${base}/content/ads?tag=new_h5_banner`;
        return get(url).then((res) => {
            commit(types.SLIDERS, res.data);
        });
    },
    /**
     * 获取专业体系课
     */
    GET_PROFESSIONAL_COURSE({ commit }) {
        const url = `${base}/courses/query`;
        return get(url).then((res) => {
            commit(types.PROFESSIONAL_COURSE, res.data.system);
        });
    },
    /**
     * 获取专项能力课
     */
    GET_SINGLE_COURSE({ commit }) {
        const url = `${base}/courses/query`;
        return get(url).then((res) => {
            commit(types.SINGLE_COURSE, res.data.single);
        });
    },
    /**
     * 获取活动
     */
    GET_ACTIVITY({ commit }) {
        const url = `${base}/activity/list/0?&page=1&pageSize=3`;
        return get(url).then((res) => {
            commit(types.ACTIVITY, res.data.result);
        });
    },
    /**
     * 获取社群列表
     */
    GET_CNAVIGATION({ commit }) {
        const url = `${base}/community/communityNavigation`;
        return get(url).then((res) => {
            commit(types.CNAVIGATION, res.data);
        });
    },
    /**
     * 获取社群首页内容列表
     */
    GET_COMMUNITY_LIST({ commit }, data) {
        const url = `${base}/community/list/${data.id}?&page=${data.page}&pageSize=${data.pageSize}`;
        return get(url).then((res) => {
            commit(types.COMMUNITY_LIST, res.data.result);
        });
    },
    /**
     * 获取社群文章详情
     */
    GET_ARTICLE_DETAIL({ commit }, id) {
        const url = `${base}/posts/detail/${id}`;
        return get(url).then((res) => {
            commit(types.ARTICLE_DETAIL, res.data.detail);
        });
    },
    /**
     * 获取社群直播讲堂详情
     */
    GET_AUDITORIUM_DETAIL({ commit }, id) {
        const url = `${base}/videos/detail/${id}`;
        return get(url).then((res) => {
            commit(types.AUDITORIUM_DETAIL, res.data.detail);
        });
    },
    /**
     * 获取社群活动详情
     */
    GET_ACTIVITY_DETAIL({ commit }, id) {
        const url = `${base}/activity/detail/${id}`;
        return get(url).then((res) => {
            commit(types.ACTIVITY_DETAIL, res.data.detail);
        });
    },
   
    /**
     * 获取所有课程
     */
    GET_COURSES({ commit }) {
        const url = `${base}/courses?page=1&pagesize=200`;
        return get(url).then((res) => {
            commit(types.COURSES, res.data);
        });
    },
    /**
     * 获取单个课程
     */
    GET_COURSE_DETAIL({ commit }, id) {
        const url = `${base}/content/page?courseid=${id}&tag=courseh5`;
        return get(url).then((res) => {
            commit(types.CURRENT_DETAIL, res.data);
        });
    },
    /**
     * 获取课程详情
     */
    GET_COURSE_DETAIL_H5({ commit }, id) {
        const url = `${base}/content/page?courseid=${id}&tag=course_h5_detail`;
        return get(url).then((res) => {
            commit(types.COURSE_DETAIL_H5, res.data);
        });
    },
    /**
     * 获取练习
     */
    GET_COURSE_EXERCISE({ commit }, data) {
        const url = `${base}/courses/${data.courseid}/exercise/${data.nodeid}`;
        return get(url, null, { "X-Auth-Token": data.token }).then((res) => {
            commit(types.COURSE_EXERCISE, res);
        })
    },
    /**
     * 获取课程模块
     */
    GET_COURSE_SECTION({ commit }, id) {
        const url = `${base}/courses/${id}/section`;
        return get(url).then((res) => {
            commit(types.CURRENT_SECTION, res.data);
        });
    },
    /**
     * 获取课程信息
     */
    GET_COURSE_INFO({ commit }, id) {
        const url = `${base}/courses/${id}`;
        return get(url).then(({ data }) => {
            commit(types.CURRENT_COURSE_INFO, { info: data, course_id: id });
        });
    },
    /**
     * 获取章节节点
     */
    GET_SECTION_NODES({ commit }, data) {
        const url = `${base}/courses/${data.course}/node/${data.section}`;
        return get(url).then((res) => {
            commit(types.SECTION_NODES, res.data);
        });
    },
    /**
     * 更新当前课程信息
     */
    UPDATE_CURRENT_COURSE({ commit }, data) {
        commit(types.CURRENT_COURSE_INFO, data);
    },
    /**
     * 获取开放平台用户信息
     */
    GET_OPEN_USER_INFO({ commit }, id) {
        const url = `${open}/user/get?openId=${id}`;
        return get(url).then((res) => {
            const playload = res.status ? Object.assign({}, res.data, { openid: id }) : { openid: "" };
            commit(types.OPEN_USER_INFO, playload);
        });
    },
    GET_USER_INFO({ commit }, id) {
        const url = `${base}/users/detail?openId=${id}`;
        commit(types.UPDATE_USER_INFO, { pending: true });
        return h5(url).get().then((res) => {
            commit(types.USER_INFO, {...res.data, pending: "resolved" });
        });
    },
    UPDATE_USER_INFO({ commit }, data) {
        commit(types.UPDATE_USER_INFO, data);
    },
    /**
     * 获取用户报名状态
     */
    GET_USER_SIGNUP_STATUS({ commit }, data) {
        const url = `${base}/students/${data.uid}/signup/${data.course_id}`;
        return get(url).then(({ data: signup }) => {
            if (signup.truename) {
                signup.trueName = signup.truename;
            }
            commit(types.SIGNUP_STATUS, signup);
        });
    },
    /**
     * 获取未支付订单
     */
    GET_UNPAID_ORDERS({ commit }, data) {
        const url = `${base}/accounting/appUnPay`;
        get(url).then((res) => {
            commit(types.UNPAID_ORDERS, res.data);
        });
    },
    /**
     * 更新订单信息
     */
    UPDATE_ORDER({ commit }, data) {
        commit(types.SET_ORDER, data);
    },
    /**
     * 获取订单信息
     */
    GET_ORDER_INFO({ commit }, id) {
        const url = `${base}/accounting/${id}/orderDetail`;
        return get(url).then(({ data: order }) => {
            if (!order) {
                return;
            }
            commit(types.SET_ORDER, {
                kid: id,
                cp_price: order.price - order.actual_price,
                amount: order.actual_price,
                name: order.name
            });
            return order;
        });
    },
    UPDATE_STUDY_LEVEL({ commit }, data) {
        commit(types.STUDY_LEVEL, data);
    },
    UPDATE_SIGNUP_INFO({ commit }, data) {
        commit(types.SIGNUP_STATUS, data);
    }
};