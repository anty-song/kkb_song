import {
    COURSES,
    SLIDERS,
    PROFESSIONAL_COURSE,
    SINGLE_COURSE,
    ACTIVITY,
    COMMUNITY_LIST,
    ARTICLE_DETAIL,
    AUDITORIUM_DETAIL,
    ACTIVITY_DETAIL,
    CNAVIGATION,
    CURRENT_DETAIL,
    COURSE_EXERCISE,
    CURRENT_SECTION,
    CURRENT_COURSE_INFO,
    SECTION_NODES,
    OPEN_USER_INFO,
    USER_INFO,
    SIGNUP_STATUS,
    UNPAID_ORDERS,
    SET_ORDER,
    UPDATE_USER_INFO,
    STUDY_LEVEL,
    COURSE_DETAIL_H5
} from "./types";

function initUser(state, data) {
    Object.keys(state.user).forEach(function(elm) {
        state.user[elm] = state.user[elm] || data[elm];
    });
}

// 创建一个 object 存储 mutation 函数
export default {
    /**
     * mutation 的第一个参数是当前的 state
     */
    [COURSES](state, res) {
        state.courses = res;
    },
    [COURSE_EXERCISE](state, res) {
        state.exercise = res;
    },
    [COURSE_DETAIL_H5](state, res) {
        state.course_detail_h5 = res;
    },
    [SLIDERS](state, data) {
        state.sliders = data;
    },
    [PROFESSIONAL_COURSE](state, data) {
        state.professional_course = data;
    },
    [SINGLE_COURSE](state, data) {
        state.single_course = data;
    },
    [ACTIVITY](state, data) {
        state.activity = data;
    },
    [COMMUNITY_LIST](state, data) {
        state.community_list = data;
    },
    [ARTICLE_DETAIL](state, data) {
        state.article_detail = data;
    },
    [AUDITORIUM_DETAIL](state, data) {
        state.auditorium_detail = data;
    },
    [ACTIVITY_DETAIL](state, data) {
        state.activity_detail = data;
    },
    [CNAVIGATION](state, data) {
        state.cnavigation = data;
    },
    [CURRENT_DETAIL](state, data) {
        state.current.detail = data;
    },
    [CURRENT_SECTION](state, data) {
        state.current.sections = data;
    },
    [CURRENT_COURSE_INFO](state, data) {
        Object.assign(state.current, data);
    },
    [SECTION_NODES](state, data) {
        state.current.chapter = data;
    },
    [OPEN_USER_INFO](state, data) {
        initUser(state, data);
    },
    [USER_INFO](state, data) {
        Object.assign(state.user, data);
    },
    [UPDATE_USER_INFO](state, data) {
        Object.assign(state.user, data);
    },
    [SIGNUP_STATUS](state, data) {
        state.current.signup_status = Object.assign({}, state.current.signup_status, data);
    },
    [UNPAID_ORDERS](state, data) {
        state.unpaid = data;
    },
    [SET_ORDER](state, data) {
        Object.assign(state.order, data);
    },
    [STUDY_LEVEL](state, data) {
        Object.assign(state.signup, data);
    }
};