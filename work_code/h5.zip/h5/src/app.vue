<!--app主入口-->
<template>
	<div id="app">
		<transition mode="out-in">
			<router-view transition="fade" transition-mode="out-in" keep-alive></router-view>
		</transition>
	</div>
</template>

<script>
	/* global PRODUCTION */
	import Vue from "vue";
	import store from "./vuex/store";
	import Cookie from "./lib/cookie";
	import { Button, Lazyload } from "mint-ui";

	Vue.use(Lazyload);
	Vue.use(Cookie);
	Vue.component(Button.name, Button);

	// import { locals } from "./config";
	export default {
		components: { },
		// 在根组件加入 store，让它的子组件和 store 连接
		store,
		data () {
			return {
				openId: null
			};
		},
		beforeMount () {
			let openid = this.$cookie.get("openid");
			if (!PRODUCTION) openid = openid || 1;
			if (!openid || openid === "null") {
				this.$cookie.delete("openid");
				return;
			}

			this.$cookie.set("openid", openid);
			store.dispatch("UPDATE_USER_INFO", { openid: openid });
			store.dispatch("GET_OPEN_USER_INFO", openid);
		}
	};

</script>

<style lang="scss">
	@import "./assets/sass/variables.scss";
	@import "./assets/sass/base.scss";
	@import "./assets/sass/reset.scss";
</style>