/**
 * 引入文件
 */
import "babel-polyfill";
import  Vue             from    "vue";
// eslint-disable-next-line no-unused-vars
import  Lib             from    "./lib";
import  App             from    "./app";
import  { router } 		from    "./router";
import 	store 			from 	"./vuex/store";
import 	VueHead 		from 	"vue-head";
import { sync } from "vuex-router-sync";

/**
 * 主样式表
 */
import  "./assets/css/app.css";

/**
 * 基础样式表
 */
import  "./assets/css/basics/reset.css";
import  "./assets/css/basics/type.css";
import  "./assets/css/basics/layout.css";

Vue.use(VueHead);
sync(store, router);

const app = new Vue({
	router,
	store,
	...App
}).$mount("#app");

export { app, router };
