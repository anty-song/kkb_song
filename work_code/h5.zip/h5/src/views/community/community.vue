<!--首页-->
<template>
	<div class="community">
		<header>
			<div class="top-box">
				<div class="title-box">
					<span class="title" @click="dropMenu">产品学吧</span>
					<span class="arrow-down" @click="dropMenu"></span>
					<div class="drop-down-list" v-show="showDropMenu">
						<ul>
							<li v-for="(item,index) in cnavigation">
								<a>
									<i :class="[iconType[index]]"></i>
									<span>{{item.title}}</span>
								</a>
							</li>
						</ul>
					</div>
				</div>
				<div class="search" @click="search"></div>
			</div>
		</header>
		<mt-swipe :auto="4000" class="slider">
			<mt-swipe-item v-for="slide in sliders">
				<a :href="slide.url" target="_blank">
					<div class="img" v-bind:style="{'background-image': 'url(' +slide.pic + ')'}">
					</div>
				</a>
			</mt-swipe-item>

		</mt-swipe>
		<div class="pane">
			<div class="communitylist">

				<div class="tabItem">
					<slot></slot>
				</div>
				<scroll :on-refresh="onRefresh" :on-infinite="onInfinite" :dataList="scrollData">
					<ul>
						<li v-for="(item,index) in listdata">
							<a :href="'kkb://communityDetail/'+item.flag+'/'+item.id+'/'">
								<!-- <div class="author">
										<span class="avatar" v-bind:style="{'background-image': 'url(' +item.avatar + ')'}"></span>
										<span class="name">{{item.nickname}}</span>
									</div> -->
								<div class="content">
									<div class="c-left">
										<div class="cover_image" v-bind:style="{'background-image': 'url(' +item.cover_image + ')'}"></div>
									</div>
									<div class="c-right">
										<p class="title">{{item.title}}</p>
										<!-- <p class="introduce">{{item.introduce}}</p> -->
										<div class="article-data">
											<span class="view_count">{{item.view_count_false}}</span>
											<span class="like_count">{{item.like_count}}</span>
											<span class="favorite_count">{{item.favorite_count}}</span>
										</div>
									</div>
								</div>
							</a>
						</li>
						<li v-for="(item,index) in downdata">
							<a :href="'kkb://communityDetail/'+item.flag+'/'+item.id+'/'">
								<!-- <div class="author">
										<span class="avatar" v-bind:style="{'background-image': 'url(' +item.avatar + ')'}"></span>
										<span class="name">{{item.nickname}}</span>
									</div> -->
								<div class="content">
									<div class="c-left">
										<div class="cover_image" v-bind:style="{'background-image': 'url(' +item.cover_image + ')'}"></div>
									</div>
									<div class="c-right">
										<p class="title">{{item.title}}</p>
										<!-- <p class="introduce">{{item.introduce}}</p> -->
										<div class="article-data">
											<span class="view_count">{{item.view_count_false}}</span>
											<span class="like_count">{{item.like_count}}</span>
											<span class="favorite_count">{{item.favorite_count}}</span>
										</div>
									</div>
								</div>
							</a>
						</li>
					</ul>
				</scroll>
			</div>
		</div>
	</div>
</template>

<style lang="scss">
header {
	display: none;
}

.community {
	background-color: #F3F6F8;
	.top-box {
		background: #f2f6f9;
		.title-box {
			height: .88rem;
			display: flex;
			justify-content: center;
		}
		.title {
			font-size: .36rem;
			color: #464646;
			font-weight: bold;
			line-height: .88rem;
			height: .8rem;
			padding-right: .2rem;
			overflow: hidden;
			cursor: pointer;
		}
		.arrow-down {
			width: .26rem;
			height: .3rem;
			background: url(../../assets/public/images/ic_back@2X.png) no-repeat;
			background-size: auto 100%;
			font-size: .3rem;
			transform: rotate(-90deg);
			margin-top: 0.22rem;
			cursor: pointer;
		}
		.drop-down-list {
			position: absolute;
			width: 100%;
			top: .88rem;
			left: 0;
			z-index: 999;
			background: rgba(255, 255, 255, .9);
			ul {
				li {
					padding: 0 .56rem;
					height: 1.16rem;
					line-height: 1.16rem;
					a {
						display: flex;
						justify-content: center;
						border-bottom: 1px solid #D9D9D9;
						i {
							width: .4rem;
							height: .4rem;
							margin-top: .38rem;
							margin-right: .21em;
						}
						.uxd_icon {
							background: url(../../assets/public/images/uxd_icon.png) no-repeat;
							background-size: auto 100%;
						}
						.pm_icon {
							background: url(../../assets/public/images/pm_icon.png) no-repeat;
							background-size: auto 100%;
						}
						span {
							font-size: .3rem;
							color: #7F8B94;
						}
					}
				}
				li:last-child {
					border-bottom: 2px solid #45D0FF;
				}
				li:last-child a {
					border: none;
				}
			}
		}
		.search {
			position: absolute;
			right: .3rem;
			top: .22rem;
			width: .38rem;
			height: .38rem;
			background: url(../../assets/public/images/search_ico.png) no-repeat;
			background-size: 100% 100%;
			cursor: pointer;
		}
	}
	.slider {
		display: none;
		background: #fff;
		height: 4.3rem;
		box-shadow: 0 2px 20px 0 rgba(186, 186, 186, .5);
		.mint-swipe-item {
			.img {
				width: 100%;
				height: 100%;
				background-size: cover;
				background-repeat: no-repeat;
				background-position: 50% 50%;
			}
		}
		.mint-swipe-indicators {
			bottom: 0px;
			.mint-swipe-indicator {
				opacity: 1;
				width: 0.1rem;
				height: 0.1rem;
				position: relative;
				background-color: rgba(255, 255, 255, 0.5);
				&:after {
					content: "";
					position: absolute;
					height: 0.22rem;
					width: 0.22rem;
					border-radius: 50%;
					border: 0.01rem solid rgba(255, 255, 255, 0.4);
					transform: scale(0.5);
					transform-origin: -0.01rem -0.01rem;
					left: 0;
					top: 0;
				}

				&.is-active {
					width: 0.2rem;
					border-radius: .1rem;
					background-color: rgba(255, 255, 255, 1);
					&:after {
						border: 0.01rem solid rgba(255, 255, 255, 0.8);
					}
				}
			}
		}
	}
}

.communitylist {
	li {
		padding: .3rem .2rem;
		padding-top: 0;
		a {
			color: #00a5e0;
			width: 100%;
			display: block;
			overflow: hidden;
			padding: .2rem;
			background: #fff;
			.author {
				display: flex;
				height: .52rem;
				line-height: .52rem;
				margin-bottom: .14rem;
				.avatar {
					border-radius: 50%;
					width: .52rem;
					height: .52rem;
					background-size: 100% 100%;
					margin-right: .16rem;
				}
				.name {
					font-size: .26rem;
					color: #848F98;
				}
			}
			.content {
				display: flex;
				.c-left {
					width: 2.88rem;
					height: 1.8rem;
					background-size: 100% 100%;
					.cover_image {
						width: 100%;
						height: 100%;
						background-size: 100% 100%;
					}
				}
				.c-right {
					width: 3.78rem;
					background-size: 100% 100%;
					padding-left: .26rem;
					position: relative;
					.title {
						padding-top: .1rem;
						font-size: .3rem;
						color: #333;
						letter-spacing: 0;
						line-height: .4rem;
						display: -webkit-box;
						-webkit-box-orient: vertical;
						-webkit-line-clamp: 2;
						overflow: hidden;
						word-wrap: break-word;
						text-overflow: ellipsis;
						line-height: .4rem;
					}
					.introduce {
						font-size: .26rem;
						color: #7F8B94;
						letter-spacing: 0;
						display: -webkit-box;
						-webkit-box-orient: vertical;
						-webkit-line-clamp: 2;
						overflow: hidden;
						word-wrap: break-word;
						text-overflow: ellipsis;
					}
					.article-data {
						position: absolute;
						bottom: 0;
						font-size: 13px;
						color: #6C7881;
						letter-spacing: 0;
						span {
							margin-right: .12rem;
						}
						.view_count {
							&:before {
								content: '';
								width: .3rem;
								height: .2rem;
								margin-right: .05rem;
								display: inline-block;
								background: url(../../assets/public/images/viewcount.png) no-repeat;
								background-size: 100% 100%;
							}
						}
						.like_count {
							&:before {
								content: '';
								width: .24rem;
								height: .24rem;
								margin-right: .05rem;
								display: inline-block;
								background: url(../../assets/public/images/like.png) no-repeat;
								background-size: 100% 100%;
							}
						}
						.favorite_count {

							&:before {
								content: '';
								width: .24rem;
								height: .24rem;
								margin-right: .05rem;
								display: inline-block;
								background: url(../../assets/public/images/favorite.png) no-repeat;
								background-size: 100% 100%;
							}
						}
					}
				}
			}
		}
	}
	li:last-child {
		margin-bottom: 0;
		padding-bottom: 0;
	}
}
</style>

<script type="text/javascript">
import { mapState } from "vuex";
import { Swipe, SwipeItem, Header } from "mint-ui";
import professional from "../../components/professional-course-list";
import communitylist from "../../components/community-list";
import scroll from "../../components/scroll";
import { post, get } from "../../api";
const base = "/api";

export default {
	name: "community",
	components: {
		[Swipe.name]: Swipe,
		[SwipeItem.name]: SwipeItem,
		[Header.name]: Header,
		Communitylist: communitylist,
		scroll: scroll
	},
	data() {
		return {
			showDropMenu: false,
			counter: 1, //默认已经显示出15条数据 count等于一是让从16条开始加载
			num: 15,  // 一次显示多少条
			pageStart: 1, // 开始页数
			pageEnd: 0, // 结束页数
			listdata: [], // 下拉更新数据存放数组
			downdata: []  // 上拉更多的数据存放数组
		}
	},
	mounted: function () {
		this.getList();
	},
	computed: {
		iconType() {
			var arr = [];
			for (var i = 0; i < this.cnavigation.length; i++) {
				arr[i] = this.cnavigation[i].urlType.toLowerCase() + "_icon";
			}
			return arr;
		},
		communitylist() {
			const c = this.$store.state.community_list;
			return c;
		},
		...mapState(["sliders", "cnavigation"]),
	},
	beforeMount() {
		this.$store.dispatch("GET_SLIDERS");
		this.$store.dispatch("GET_CNAVIGATION");

	},
	methods: {
		search() {
			location.href = "kkb://search/";
		},
		dropMenu() {
			this.showDropMenu = !this.showDropMenu
		},
		communityType(urltype) {
			return urltype.toLowerCase()
		},
		getList() {
			let _this = this;
			return get(`${base}/community/list/` + _this.$route.params.id + `?&page=` + _this.pageStart + `&pageSize=` + _this.num).then((res) => {
				_this.listdata = res.data.result;
			}, (res) => {
				console.log('error');
			});
		},
		onRefresh(done) {
			this.getList();
			done(); // call done
		},
		onInfinite(done) {
			let _this = this;
			_this.counter++;
			return get(`${base}/community/list/` + _this.$route.params.id + `?&page=` + _this.counter + `&pageSize=` + _this.num).then((res) => {
				if (!res.data) {
					this.$el.querySelector('.load-more').innerHTML = '暂无更多数据';
					return;
				}
				let arr = res.data.result;
				for (var i = 0; i < arr.length; i++) {
					_this.downdata.push(arr[i]);
				}
				done()
			}, (res) => {
				console.log('error');
			});
		}
	},
	head: {
		title: {
			inner: "社群"
		}
	}

};
</script>