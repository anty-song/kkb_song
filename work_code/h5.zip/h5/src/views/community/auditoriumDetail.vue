<!--首页-->
<template>
	<div class="auditorium_detail">
		<h2 class="title">{{auditorium_detail.title}}</h2>
		<div class="author">
			<span class="sending_time">发布于{{auditorium_detail.sending_time}}</span>
		</div>
		<div v-html="auditorium_detail.content" class="content">
			{{auditorium_detail.content}}
		</div>
		<div class="collect_div">
			<span :class="{active:isLike,'like':true}" @click="like">{{auditorium_detail.like_count}}</span>
			<span :class="{active:isCollect,'collect':true}" @click="collect">{{auditorium_detail.favorite_count}}</span>
		</div>
	</div>
</template>

<style lang="scss">
.auditorium_detail {
	padding: .30rem;
	span,
	a {
		display: inline-block;
	}
	.title {
		font-size: .4rem;
		color: #323232;
		letter-spacing: 0;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		word-wrap: break-word;
		text-overflow: ellipsis;
		overflow: hidden;
	}
	.author {
		display: flex;
		height: .52rem;
		line-height: .52rem;
		margin-top: .26rem;
		margin-bottom: .26rem;
		font-size: .26rem;
		color: #8A959D;
	}
	.content {
		p {
			margin: 0 0 .2rem;
		}
		font-size: .32rem;
		color: #3E3E3E;
		letter-spacing: 0;
		margin-top: .22rem;
		overflow: hidden;
		img {
			max-width: 100%;
			margin: 0 auto;
		}
	}
	.collect_div {
		font-size: .16rem;
		text-align: center;
		margin-top: .80rem;
		.like {
			color: #F07474;
			display: inline-block;
			width: 2.66rem;
			height: .70rem;
			line-height: .7rem;
			background: url(../../assets/public/images/like_btn.png) no-repeat;
			background-size: 100%;
			padding-left: 1.5rem;
			margin-right: .3rem;
			font-size: .3rem;
			cursor: pointer;
		}
		.like.active {
			color: #fff;
			background: url(../../assets/public/images/like_btn_active.png) no-repeat;
			background-size: 100%;
		}
		.collect {
			display: inline-block;
			width: 2.66rem;
			height: .70rem;
			line-height: .7rem;
			background: url(../../assets/public/images/collect_btn.png) no-repeat;
			background-size: 100%;
			color: #FDAF37;
			padding-left: 1.5rem;
			font-size: .3rem;
			cursor: pointer;
		}
		.collect.active {
			color: #fff;
			background: url(../../assets/public/images/collect_btn_active.png) no-repeat;
			background-size: 100%;
		}
	}
}
</style>

<script type="text/javascript">
import { mapState } from "vuex";
import { post, get } from "../../api";
const base = "/api";
export default {
	name: "auditorium",
	data() {
		return {
			isLike: false,
			isCollect: false
		}
	},
	components: {
	},
	computed: {

		...mapState(["auditorium_detail"])
	},
	beforeMount() {
		this.$store.dispatch("GET_AUDITORIUM_DETAIL", this.$route.params.id);
	},
	beforeUpdate() {
		this.isLikeCollect();
	},
	methods: {
		like() {
			if (this.isLike) {
				return;
			}
			if (this.$route.query.token == 0) {
				location.href = "kkb://login/";
				return;
			}
			return post(`${base}/qa/like/` + this.$route.params.id, {
				"itemType": this.auditorium_detail.type
			}, {
					"X-Auth-Token": this.$route.query.token
				}).then((res) => {
					if (res.error_code == 0) {
						this.auditorium_detail.like_count++;
						// location.href="kkb://message/"+"点赞成功！"
					}
				});
		},
		collect() {
			if (this.$route.query.token == 0) {
				location.href = "kkb://login/";
				return;
			}
			if (this.isCollect) {
				this.cancelCollect();
				return;
			}
			return post(`${base}/qa/collection/click/` + this.$route.params.id, {
				"itemType": this.auditorium_detail.type
			}, {
					"X-Auth-Token": this.$route.query.token
				}).then((res) => {
					if (res.error_code == 0) {
						this.auditorium_detail.favorite_count++;
						// location.href="kkb://message/"+"收藏成功！"
					}
				});
		},
		cancelCollect() {
			return post(`${base}/qa/collection/cancel/` + this.$route.params.id, {
				"itemType": this.auditorium_detail.type
			}, {
					"X-Auth-Token": this.$route.query.token
				}).then((res) => {
					if (res.error_code == 0) {
						this.auditorium_detail.favorite_count--;
						this.isCollect = false;
						// location.href="kkb://message/"+"收藏成功！"
					}
				});
		},
		isLikeCollect() {
			var _this = this;
			if (this.$route.query.token == 0) {
				return;
			}
			return get(`${base}/qa/item/status/` + this.$route.params.id + `?itemType=` + this.auditorium_detail.type, {
			}, {
					"X-Auth-Token": this.$route.query.token
				}).then((res) => {
					if (res.error_code == 0) {
						_this.isLike = res.data.like;
						_this.isCollect = res.data.collection;
					}
				});
		}
	},
	head: {
		title: {
			inner: "大讲堂"
		}
	}

};
</script>