<!--首页-->
<template>
	<div class="index">
		<header class="mint-header">
			<img class="logo" src="/img/home/logo@3x.png" alt="logo">
		</header>
		<mt-swipe :auto="4000" class="slider">
			<mt-swipe-item v-for="slide in sliders">
			<a :href="slide.url" target="_blank">
				<div class="img" 
					v-bind:style="{'background-image': 'url(' +slide.pic + ')'}" >
				</div>
			</a>
			</mt-swipe-item>
		</mt-swipe>
		<!-- 4个图标 -->
		<div class="cols flex">
			<div class="icon">
				<img src="/img/home/ic_index_kh1@3x.png">
				<p>系统教学</p>
			</div>
			<div class="icon">
				<img src="/img/home/ic_index_kh2@3x.png">
				<p>实战演练</p>
			</div>
			<div class="icon">
				<img src="/img/home/ic_index_kh3@3x.png">
				<p>名师辅导</p>
			</div>
			<div class="icon">
				<img src="/img/home/ic_index_kh4@3x.png">
				<p>就业保障</p>
			</div>
		</div>
		<div class="order-notify" v-if="upaid_order">
		<router-link :to="{name: 'orders'}">
			<img src="/img/home/index_dd_note@3x.png" class="icon">
			您还有订单未完成支付
			
			<span class="pull-right">前往查看 <img class="icon-more" src="/img/home/index_dd_jt@3x.png"></span>
		</router-link>
		</div>

		<div class="pane">
			<h2 class="title">热门课程</h2>
			<course :courses="hot" class="body hot" :small="true"></course>
		</div>
		<div class="pane">
			<h2 class="title">热门课程</h2>
			<course :courses="rec" class="body rec column"></course>
		</div>
	</div>
</template>

<style lang="scss">
	.index {
		background-color: #F6F5F5;
		
		.logo {
			display: block;
			height: 0.4rem;
			margin: auto;
		}

		.slider {
			height: 2.6rem;

			.mint-swipe-item {
				background: #ddd;

				.img {
					width: 100%;
					height: 100%;
					background-size: cover;
					background-repeat: no-repeat;
					background-position: 50% 50%;
				}
			}

			.mint-swipe-indicators {
				bottom: 0px;

				.mint-swipe-indicator {
					opacity: 1;
					width: 0.1rem;
					height: 0.1rem;
					position: relative;
					background-color: rgba(0,0,0,0.15);
					
					&:after {
						content: "";
						position: absolute;
						height: 0.22rem;
						width: 0.22rem;
						border-radius: 50%;
						border: 0.01rem solid rgba(255,255,255, 0.4);
						transform: scale(0.5);
						transform-origin: -0.01rem -0.01rem;
						left: 0;
						top: 0;
					}

					&.is-active {
						background-color: rgba(0,0,0,0.5);
						
						&:after {
							border: 0.01rem solid rgba(255,255,255, 0.8);
						}
					}
				}
			}
		}

		.cols {
			background-color: #fff;
			font-size: 0;
			width: 100%;
			
			.icon {
				position: relative;
				width: 25%;
				text-align: center;
				padding: 0.32rem 0;

				&:after {
					content: "";
					position: absolute;
					top: 50%;
					height: 0.82rem;
					margin-top: -0.41rem;
					right: 0;
					border-right: 0.01rem solid #e9e9e9;
					transform: scaleX(0.5);
				}

				&:last-child {
					&:after {
						border-right: none;
					}
				}

				img {
					width: 0.48rem;
					height: 0.48rem;
				}

				p {
					margin-top: 0.04rem;
					font-size: 0.22rem;
					color: #999;
				}
			}
		}

		.order-notify {
			background-color: #FFF9ED;
			font-size: 0.26rem;
			color: #F5A800;
			padding: 0.22rem 0.3rem;
			line-height: 0.37rem;

			.icon {
				height: 0.3rem;
				width: 0.38rem;
				vertical-align: middle;
				margin-right: 0.1rem;
			}

			a {
				color: #F5A800;

				.icon-more {
					height: 0.2rem;
				}
			}
		}

		.hot {
			.course-item {
				margin-bottom: 0;

				.category {
					display: none;
				}
			}
		}

		.rec {
			.course-item {
				img {
					min-height: 1.98rem;
					background: #e9e9e9;
				}
			}
		}
	}
</style>

<script type="text/javascript">
	import { mapState } from "vuex";
	import { Swipe, SwipeItem, Header } from "mint-ui";
	import Course from "../components/course-item";

	export default {
		name: "Home",
		components: {
			[Swipe.name]: Swipe,
			[SwipeItem.name]: SwipeItem,
			[Header.name]: Header,
			course: Course
		},
		computed: {
			hot () {
				const c = this.$store.state.courses;
				return c && c.count ? c.courses.slice(0, 2) : [];
			},
			rec () {
				const c = this.$store.state.courses;
				return c && c.count ? c.courses.slice(2) : [];
			},
			upaid_order () {
				return this.$store.state.unpaid && this.$store.state.unpaid.length;
			},
			...mapState(["sliders"])
		},
		beforeMount () {
			if (this.$store.state.courses.count) {
				return;
			}
			this.$store.dispatch("GET_SLIDERS");
			this.$store.dispatch("GET_COURSES");
			if (!this.$store.state.unpaid || !this.$store.state.unpaid.length) {
				this.$store.dispatch("GET_UNPAID_ORDERS");
			}
		},
		head: {
			title: {
				inner: "首页"
			}
		}
	};
</script>