<template>
	<div>
		<mt-header title="课程报名">
			<div slot="right">
				<a href="http://kefu8.kuaishang.com.cn/bs/im.htm?cas=30989___418723&fi=35187&ism=1&sText=GaoXiaoBang&ref=H5"
			 target="_blank" >咨询</a>
			</div>
		</mt-header>
		<div class="jumbotron">
			<img src="/img/signup/bm_top_bg@3x.jpg">
			<h2>报名{{ course_name }}就业班级</h2>
		</div>
		<form class="input-group-form signup-form" method="POST">
			<mt-field placeholder="请输入您的姓名" class="input-group" v-model.trim="form.trueName">
				<img src="/img/signup/ic_bm_name@3x.png" class="icon">
			</mt-field>
			<mt-field placeholder="请输入您的手机号" class="input-group" type="tel" v-model.trim="form.mobile">
				<img src="/img/signup/ic_bm_phone@3x.png" class="icon">
			</mt-field>
			<mt-field placeholder="请输入您的QQ号" class="input-group" type="number" v-model.trim="form.qq">
				<img src="/img/signup/ic_bm_qq@3x.png" class="icon">
			</mt-field>
			<div class="input-group">
				<img src="/img/signup/ic_bm_mb@3x.png" class="icon">
				<select name="target" class="inp" v-model="signup.target">
					<option>在校生想顺利就业</option>
					<option>在校生想创业</option>
					<option>应届毕业生就业</option>
					<option>在职转岗</option>
					<option>在岗想升职加薪</option>
					<option>为创业储备</option>
					<option>其他</option>
				</select>
				<img src="/img/signup/bm_jt_down@3x.png" class="arrow">
			</div>
			<div class="input-group">
				<img src="/img/signup/ic_bm_jc@3x.png" class="icon">
				<select name="basis" class="inp" v-model="signup.basis">
					<option>完全是行业小白</option>
					<option>在行业内,缺乏目标岗位经验</option>
					<option>有部分岗位能力经验</option>
				</select>
				<img src="/img/signup/bm_jt_down@3x.png" class="arrow">
			</div>
			<mt-button type="danger" class="btn-block" :disabled="submitting"  @click.native.prevent="submit()">{{ submitting ? '提交中...' : '立即报名'}}</mt-button>
		</form>
	</div>
</template>

<style lang="scss">
	.signup-form {
		.mint-field-other{
			right: initial;
			left: 0rem;
			top: 50%; 
		}
	}

	.jumbotron {
		position: relative;
		min-height: 3rem;
		font-size: 0;

		img {
			width: 100%;
		}

		h2 {
			position: absolute;
			top: 0;
			width: 100%;
			font-size: 0.4rem;
			text-align: center;
			color: #FFF;
			line-height: 3rem;
		}
	}

	.input-group-form {
		padding: 0.2rem 0.3rem;

		.mint-button {
			font-size: 0.28rem;
			height: 0.9rem;
		}
	}

	.input-group {
		position: relative;
		height: 0.9rem;
		margin-bottom: 0.2rem;
		font-size: 0.28rem;
		background: #fff;
		border-radius: 0.08rem;

		input, select {
			height: 0.9rem;
			width: 100%;
			-webkit-appearance: none;
			border: none;
			background: none;
			padding: 0.2rem 0.8rem 0.2rem;
			color: #3F3939;
		}

		.icon {
			position: absolute;
			left: 0.3rem;
			top: 50%;
			margin-top: -0.18rem;
			height: 0.34rem;
			width: 0.34rem;
		}

		.arrow {
			position: absolute;
			right: 0.3rem;
			height: 0.13rem;
			width: 0.25rem;
			top: 50%;
			margin-top: -0.065rem;
		}

		&:last-child {
			margin-bottom: 0;
		}
	}
</style>

<script>
	import { Header, Field, Toast as toast } from "mint-ui";
	import { h5 as api } from "../../api";
	import { router } from "../../router";
	import store from "../../vuex/store";

	export default {
		name: "Signup",
		components: {
			[Header.name]: Header,
			[Field.name]: Field
		},
		data () {
			return {
				signup: {
					target: this.$store.state.signup.target,
					basis: this.$store.state.signup.basis,
				},
				submitting: false
			};
		},
		computed: {
			course_name () {
				return this.$store.state.current.info && this.$store.state.current.info.name;
			},
			form () {
				return {
					trueName: this.$store.state.user.trueName || this.$store.state.user.name,
					mobile: this.$store.state.user.mobile,
					qq: this.$store.state.user.qq
				};
			}
		},
		beforeRouteEnter (to, from, next) {
			// 刷新页面时获取课程信息
			const signupStatus = store.state.current.signup_status;
			const course = to.params.course;
			const user = store.state.user;
			function redirect () {
				if (store.state.current.signup_status.signup) {
					next({
						name: "checkout",
						params: { id: course }
					});
				} else {
					next();
				}
			}

			if (!signupStatus.mobile && user.uid) {
				store.dispatch("GET_USER_SIGNUP_STATUS", {
					uid: user.uid || user.openid, course_id: course
				}).then(() => {
					redirect();
				});
				return;
			}

			redirect();
		},
		beforeMount () {
			// 刷新页面时获取课程信息
			const c = store.state.current;
			const course = this.$route.params.course;

			if (!c.info || !c.info.course_id) {
				store.dispatch("GET_COURSE_INFO", course);
			}
		},
		methods: {
			submit () {
				if (!this.form.trueName) {
					toast("请输入您的姓名");
					return;
				}
				if (!this.form.mobile || !/^1\d{10}$/.test(this.form.mobile)) {
					toast("请输入正确的手机号");
					return;
				}
				if (!this.form.qq || /^\d+$/.test(this.form.q)) {
					toast("请输入正确的QQ号");
					return;
				}

				// 更新报名信息
				this.$store.dispatch("UPDATE_STUDY_LEVEL", this.signup);

				const user = this.$store.state.user;
				const cid = this.$route.params.course;
				const url = `/api/enroll/signUp?courseId=${cid}`;

				this.submitting = true;

				api(url, { openId: user.openid, ...this.form, ...this.signup })
					.post()
					.then(({ data, error_code, error_msg }) => { /* eslint-disable */
						if (error_code === 0 && data.uid) {
							const update = this.$store.state.user.uid ? data : Object.assign({ }, data, this.form);
							this.$store.dispatch("UPDATE_USER_INFO", update);
							this.$store.dispatch("UPDATE_SIGNUP_INFO", this.form);
							router.push({ name: "checkout", params: { id: cid }});
						} else {
							var message = "";
							if(error_code === 50402) {
								message = "您已经报过名了";
							} else {
								message = error_msg || "未知错误";
							}
							toast({
								message: message, position: "bottom", duration: 5000
							});
						}
						this.submitting = false;
					}, ( err ) => {
						this.submitting = false;
					});
			}
		}
	};
</script>
