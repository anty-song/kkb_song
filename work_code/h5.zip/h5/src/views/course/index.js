import Course from "./Info.vue";
import Section from "./section.vue";
import Signup from "./signup.vue";
import Result from "./result.vue";
import courseDetail from "./courseDetail.vue";

export {
	Course,
	Section,
	Signup,
	Result,
	courseDetail
};
