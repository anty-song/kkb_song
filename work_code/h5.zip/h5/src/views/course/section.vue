<template>
	<div class="section">
		<player :vid="currentVid">
			<play-list :nodes="chapter.nodes" @play="play" :start="node" @mask="setMask"></play-list>
			<div class="player-mask" v-show="this.maskType !== 'hide'">
				<div class="content-wrapper" v-if="this.maskType === 'not_buy'">
					<p>快来报名，老师带你实战！</p>
					<a href="http://kefu8.kuaishang.com.cn/bs/im.htm?cas=30989___418723&fi=35187&ism=1&sText=GaoXiaoBang&ref=H5" class="btn btn-hollow mr50" target="_blank">咨询课程顾问</a>
					<router-link :to="{name: 'signup', params: {course: course}}" class="btn btn-danger">即刻报名</router-link>
				</div>
			</div>
		</player>
	</div>
</template>

<style lang="scss">
	.player-mask {
		position: absolute;
		width: 100%;
		height: 3.6rem;
		top: 0;
		left: 0;
		color: #fff;
		display: table;
		background: #000;
		z-index: 9999;

		.content-wrapper {
			height: 100%;
			display: table-cell;
			vertical-align: middle;
			text-align: center;

			p {
				font-size: 0.28rem;
				line-height: 0.42rem;
				margin-bottom: 0.25rem;
			}

			.btn {
				display: inline-block;
				padding: 0;
				line-height: 0.58rem;
				height: 0.58rem;
				width: 1.9rem;
				font-size: 0.28rem;
			}

			.mr50 {
				margin-right: 0.45rem;
			}
		}
	}
</style>

<script>
	import "../../assets/js/lib/polyvplayer";
	import { Player, PlayList } from "../../components";

	export default {
		name: "Section",
		computed: {
			chapter () {
				return this.$store.state.current.chapter;
			}
		},
		beforeMount () {
			this.$store.dispatch("GET_SECTION_NODES", {
				course: this.course,
				section: this.section
			}).then(() => {
				this.$nextTick(() => {
					this.start();
				});
			});
		},
		components: {
			"player": Player,
			"play-list": PlayList
		},
		data () {
			return {
				course: this.$route.params.course,
				section: this.$route.params.section,
				node: {},
				currentVid: null,
				maskType: "hide"
			};
		},
		methods: {
			play (node) {
				this.maskType = "hide";
				this.currentVid = node.vid;
			},
			start () {
				this.maskType = "hide";
				const [node] = this.$store.state.current.chapter.nodes;
				this.node = node;
			},
			setMask (type) {
				this.maskType = type;
			}
		}
	};
</script>
