<template>
	<div class="course-info course">
		<!-- <div class="course-cover">
            <img :src="'/public/images/cover/top_cover_'+course_id+'.png'" width="100%">
        </div> -->
		<header class="tab-header" :class="{fixed: fixed}">
            <nav>
                <a class="iblock tabnav" :class="{active: active == 'course-section'}" @click="setTab('course-section')">课程大纲</a>
                <a class="iblock tabnav" :class="{active: active == 'course-detail'}" @click="setTab('course-detail')">课程介绍</a>
            </nav>
            <a href="http://kefu8.kuaishang.com.cn/bs/im.htm?cas=30989___418723&fi=35187&ism=1&sText=GaoXiaoBang&ref=H5"
               class="right-link" target="_blank">咨询</a>
        </header>
        <keep-alive>
			<mt-tab-container v-model="active" class="info-content">
				<mt-tab-container-item id="course-section">
					<course-section :course="{ course_id, info, sections, tutors}"></course-section>
			  	</mt-tab-container-item>
			  	<mt-tab-container-item id="course-detail">
			  		<div class="detail-wrap-hook"></div>
			  	</mt-tab-container-item>
			</mt-tab-container>
        </keep-alive>

		<footer class="footer-fixed" style="display:none">
			<div class="wrap">
	        	<a class="left self" @click="trial()">免费试听</a>
	        	<a class="right sign" @click="signup()">报名就业班</a>
			</div>
	    </footer>
	</div>
</template>

<style lang="scss">
	@import "../../assets/sass/detail.scss";
	.course-info {
		width: inherit;
	}
	.course-cover {
		font-size: 0;
		img {
			height: 3rem;
		}
	}
	
	.tab-header {
		position: -webkit-sticky;
		position: sticky;
		width: 100%;
		top: 0;
		z-index: 50;
		border-bottom: 1px solid #f5f5f5;
	}

	.tab-header.fixed {
		position: fixed;
		width: inherit;
	}

	.course .footer-fixed {
		width: inherit;
		left: initial;
	}

</style>

<script>
	import { TabContainer, TabContainerItem } from "mint-ui";
	import courseSection from "../../components/course-section";
	import utils from "../../utils/utils";
	import { make } from "../../components/course-info";
	import { router } from "../../router";
	import store from "../../vuex/store";

	export default {
		name: "Course",
		data: function () {
			return {
				course_id: this.$route.params.id,
				active: "course-section",
				fixed: false,
				infoComponent: null
			};
		},
		components: {
			[TabContainer.name]: TabContainer,
			[TabContainerItem.name]: TabContainerItem,
			[courseSection.name]: courseSection
		},
		beforeRouteEnter (to, from, next) {
			// 清空原数据
			store.dispatch("UPDATE_CURRENT_COURSE", {
				course_id: to.params.id,
				detail: "",
				info: {},
				sections: []
			});
			store.dispatch("GET_COURSE_INFO", to.params.id);
			store.dispatch("GET_COURSE_DETAIL", to.params.id);
			store.dispatch("GET_COURSE_SECTION", to.params.id);
			// 获取用户报名情况
			const user = store.state.user;
			const getUserSignupInfo = () => {
				store.dispatch("GET_USER_SIGNUP_STATUS", {
					uid: user.uid || user.openid,
					course_id: to.params.id
				}).then(() => {
					next();
				}, () => next());
			};

			// 已登录用户
			if (user.uid && user.token) {
				getUserSignupInfo();
			} else {
			// 未登录用户
				next();
			}
		},
		beforeMount () {
			const current = store.state.current;
			if (current.detail) {
				this.infoComponent = make("courseInfo", store.state.current.detail, this.$route.params.id);
				return;
			}

			store.subscribe((mutation, state) => {
				if (mutation.type === "CURRENT_DETAIL") {
					this.infoComponent = make("courseInfo", state.current.detail, this.$route.params.id);
				}
			});
		},
		watch: {
			infoComponent () {
				//添加 详情内容
				this.infoComponent.$mount(".detail-wrap-hook");
				this.$forceUpdate();
			}
		},
		mounted () {
			// var headerImgH = document.querySelectorAll(".course-cover")[0].offsetHeight;
			// var vm = this;
			// if (!utils.bowser.versions.ios) {
			// 	window.onscroll = function () {
			// 		if (document.body.scrollTop > headerImgH) {
			// 			vm.fixed = true;
			// 		} else {
			// 			vm.fixed = false;
			// 		}
			// 	};
			// }
		},
		computed: {
			info () {
				return this.$store.state.current.info;
			},
			tutors () {
				const info = this.$store.state.current.info;
				return info.lecture ? info.lecture.split("、") : [];
			},
			sections () {
				return this.$store.state.current.sections || [];
			},
			detail () {
				return this.$store.state.current.detail;
			},
			signup_status () {
				return this.$store.state.current.signup_status || {};
			}
		},
		head: {
			title: {
				inner: "课程"
			}
		},
		methods: {
			setTab (target) {
				this.active = target;
			},
			trial () {
				const [{ subs: [first] }] = this.$store.state.current.sections;
				router.push({
					name: "section",
					params: { course: this.course_id, section: first.subid }
				});
			},
			signup () {
				const bought = this.signup_status.buytype === 1;
				if (bought) {
					router.push({ name: "alert", query: { result: "bought" }});
				} else {
					router.push({ name: "signup", params: { course: this.course_id }});
				}
			}
		}
	};
</script>