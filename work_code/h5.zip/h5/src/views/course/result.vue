<template>
	<div>
		<div class="wrapper">
			<div class="result" :is="data.result"></div>
			<div class="qa-list">
				<a href="http://kefu8.kuaishang.com.cn/bs/im.htm?cas=30989___418723&fi=35187&ism=1&sText=GaoXiaoBang&ref=H5" 
				target="_blank" class="qa">
					<img src="/img/signup/img_bm_tx_zx@3x.png" alt="咨询" class="icon">
					咨询课程顾问MM
				</a>
				<a href="tel:010-57161262" class="qa">
					<img src="/img/signup/img_bm_tx_phone@3x.png" alt="呼叫" class="icon">
					呼叫课程顾问MM
				</a>
			</div>
		</div>
	</div>
</template>

<style lang="scss">
	@import "../../assets/sass/variables.scss";
	body {
		position: relative;
		min-height: 9.6rem;
	}

	.wrapper {
		padding: 0.9rem 0.4rem 0;
	}

	.result	{
		text-align: center;
		font-size: 0;

		&.error, &.failed {
			h1 {
				color: $red;
			}
		}

		h1 {
			color: $blue;
			font-size: 0.46rem;
			line-height: 0.65rem;
			margin-bottom: 0.1rem;
			vertical-align: middle;

			img {
				display: inline-block;
				width: 0.48rem;
				height: 0.48rem;
				margin-right: 0.2rem;
				vertical-align: middle;
			}
		}

		h4 {
			width: 90%;
			margin: auto;
			text-align: left;
			color: $dark;
			font-size: 0.26rem;
			line-height: 0.37rem;
		}

		.result-img {
			width: 75%;
			margin-top: 0.5rem;
		}

		p {
			font-size: 0.26rem;
			text-align: left;
			line-height: 0.42rem;
			color: $grey;
			margin-bottom: 0.2rem;
		}

		.small {
			color: $light-gray;
			text-align: center;
			margin-bottom: 0.5rem;
		}

		.hint {
			font-size: 0.26rem;
			color: $light-gray;
			text-align: left;
			line-height: 0.42rem;
			margin-top: 0.5rem;
		}

		.mint-button {
			margin-top: 0.4rem;
			height: 0.78rem;
			line-height: 0.78rem;
			font-size: 0.28rem;

			&.half {
				display: inline-block;
				width: 2.65rem;
			}

			&.mint-button--default {
				color: $light-gray;
				box-shadow: 0 0 0 1px #d9d9d9;
			}
		}

		.mr30 {
			margin-right: 0.3rem;
		}
	}

	.qa-list {
		position: absolute;
		left: 0;
		right: 0;
		bottom: 0;
		font-size: 0.28rem;
		padding: 0 0.4rem;

		.qa {
			display: block;
			color: $light-gray;
			line-height: 1rem;

			&:first-child {
				border-bottom: 1px solid #e9e9e9;
			}

			.icon {
				width: 0.36rem;
				vertical-align: middle;
				margin-right: 0.12rem;
			}
		}
	}
</style>

<script>
	import * as result from "../../components/result";

	export default {
		data () {
			return {
				data: this.$route.query
			};
		},
		beforeRouteEnter (to, from, next) {
			if (to.query.result === "fail" && !to.query.thirdOrderNo) {
				return next("/");
			}
			const valid = ~Object.keys(result).indexOf(to.query.result);
			valid ? next() : next("/");
		},
		name: "Result",
		components: {
			...result
		},
		computed: {}
	};

</script>