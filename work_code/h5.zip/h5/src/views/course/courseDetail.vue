<template>
	<div class="course-detail" v-html="course_detail_h5">
	</div>
</template>

<style lang="scss">
.course-detail {
	p {
		width: 100%;
		background-size: 100% 100%;
		background-repeat: no-repeat;
	}
	.pm-one {
		height: 11.05rem;
		background-image: url("../../assets/public/images/pm_course_detail/one.png");
	}
	.pm-two {
		height: 7.48rem;
		background-image: url("../../assets/public/images/pm_course_detail/two.png");
	}
	.pm-three {
		height: 12.75rem;
		background-image: url("../../assets/public/images/pm_course_detail/three.png");
	}
	.pm-four {
		height: 12.94rem;
		background-image: url("../../assets/public/images/pm_course_detail/four.png");
	}
	.pm-five {
		height: 6.93rem;
		background-image: url("../../assets/public/images/pm_course_detail/five.png");
	}
	.pm-six {
		height: 9.93rem;
		background-image: url("../../assets/public/images/pm_course_detail/six.png");
	}
	.uxd-one {
		height: 11.06rem;
		background-image: url("../../assets/public/images/uxd_course_detail/one.jpg");
	}
	.uxd-two {
		height: 8.91rem;
		background-image: url("../../assets/public/images/uxd_course_detail/two.jpg");
	}
	.uxd-three {
		height: 10.98rem;
		background-image: url("../../assets/public/images/uxd_course_detail/three.jpg");
	}
	.uxd-four {
		height: 8.4rem;	
		background-image: url("../../assets/public/images/uxd_course_detail/four.jpg");
	}
	.uxd-five {
		height: 9.61rem;
		background-image: url("../../assets/public/images/uxd_course_detail/five.jpg");
	}
}
</style>

<script>
import { mapState } from "vuex";
export default {
	name: "courseDetail",
	beforeMount() {
		this.$store.dispatch("GET_COURSE_DETAIL_H5", this.$route.params.id);
	},
	computed: {
		...mapState(["course_detail_h5"])
	},
	methods: {

	}
};
</script>