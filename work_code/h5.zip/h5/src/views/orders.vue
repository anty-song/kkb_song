<template>
	<div>
		<mt-header title="未完成订单"></mt-header>
		<order-item :orders="orders"></order-item>
	</div>
</template>

<script>
	import { Header } from "mint-ui";
	import Order from "../components/order-item";
	import store from "../vuex/store";

	export default {
		name: "Orders",
		components: {
			[Header.name]: Header,
			"order-item": Order
		},
		data () {
			return {
				orders: {}
			};
		},
		beforeMount () {
			store.dispatch("GET_UNPAID_ORDERS");
		},
		computed: {
			orders () {
				return this.$store.state.unpaid;
			}
		}
	};
</script>
