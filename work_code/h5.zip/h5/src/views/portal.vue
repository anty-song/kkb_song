<!--首页-->
<template>
	<div class="portal">
		<div class="search" @click="search">
			<i class="search-icon"></i>
			<input disabled placeholder="产品经理">
		</div>
		<mt-swipe :auto="4000" class="slider">
			<mt-swipe-item v-for="slide in sliders" v-if="">
				<a :href="'kkb://swipe/'+slide.url" target="_blank">
					<div class="img" v-bind:style="{'background-image': 'url(' +slide.pic + ')'}">
					</div>
				</a>
			</mt-swipe-item>
		</mt-swipe>
		<div class="order-notify" v-if="upaid_order">
			<router-link :to="{name: 'orders'}">
				<img src="/img/home/index_dd_note@3x.png" class="icon"> 您还有订单未完成支付

				<span class="pull-right">前往查看
					<img class="icon-more" src="/img/home/index_dd_jt@3x.png">
				</span>
			</router-link>
		</div>
		<div class="pane">
			<h2 class="title">
				<span>-</span> 专业体系课
				<span>-</span>
			</h2>
			<h3 class="sub-title">系统掌握一项专业所需的解决方案</h3>
			<professional :professional_course="proCourse"></professional>
		</div>
		<div class="pane">
			<h2 class="title">
				<span>-</span> 专项能力课
				<span>-</span>
			</h2>
			<h3 class="sub-title">提供特定、热门、新潮的专题课程。</h3>
			<single :single_course="singleCourse"></single>
		</div>
		<div class="pane">
			<h2 class="title">
				<span>-</span> 活动
				<span>-</span>
			</h2>
			<h3 class="sub-title">大咖分享、聚会沙龙、公开课直播，都在这里。</h3>
			<activity :activity="activity"></activity>
		</div>
	</div>
</template>

<style lang="scss">
.portal {
	background-color: #F3F6F8;
	.search {
		display: none;
		position: absolute;
		top: .52rem;
		left: .85rem;
		z-index: 9999;
		width: 5.8rem;
		height: .6rem;
		font-size: .26rem;
		text-align: center;
		background-color: #fff;
		border-radius: 1rem;
		line-height: .6rem;
		.search-icon {
			display: inline-block;
			vertical-align: middle;
			width: .27rem;
			height: .27rem;
			background: url(../assets/public/images/search_ico.png) no-repeat;
			background-size: 100% 100%;
		}
		input {
			display: inline-block;
			vertical-align: middle;
			border: none;
			background-color: #fff;
		}
	}
	.slider {
		height: 3.75rem;
		.mint-swipe-indicators {
			display: none;
		}
		.mint-swipe-item {
			background: #ddd;

			.img {
				width: 100%;
				height: 100%;
				background-size: cover;
				background-repeat: no-repeat;
				background-position: 50% 50%;
			}
		}

		.mint-swipe-indicators {
			bottom: 0px;

			.mint-swipe-indicator {
				opacity: 1;
				width: 0.1rem;
				height: 0.1rem;
				position: relative;
				background-color: rgba(255, 255, 255, 0.5);

				&:after {
					content: "";
					position: absolute;
					height: 0.22rem;
					width: 0.22rem;
					border-radius: 50%;
					border: 0.01rem solid rgba(255, 255, 255, 0.4);
					transform: scale(0.5);
					transform-origin: -0.01rem -0.01rem;
					left: 0;
					top: 0;
				}

				&.is-active {
					width: 0.2rem;
					border-radius: .1rem;
					background-color: rgba(255, 255, 255, 1);
					&:after {
						border: 0.01rem solid rgba(255, 255, 255, 0.8);
					}
				}
			}
		}
	}

	.order-notify {
		background-color: #FFF9ED;
		font-size: 0.26rem;
		color: #F5A800;
		padding: 0.22rem 0.3rem;
		line-height: 0.37rem;

		.icon {
			height: 0.3rem;
			width: 0.38rem;
			vertical-align: middle;
			margin-right: 0.1rem;
		}

		a {
			color: #F5A800;

			.icon-more {
				height: 0.2rem;
			}
		}
	}

	.hot {
		.course-item {
			margin-bottom: 0;

			.category {
				display: none;
			}
		}
	}

	.rec {
		.course-item {
			img {
				min-height: 1.98rem;
				background: #e9e9e9;
			}
		}
	}
}
</style>

<script type="text/javascript">
import { mapState } from "vuex";
import { Swipe, SwipeItem, Header } from "mint-ui";
import professional from "../components/professional-course-list";
import single from "../components/single-course-list";
import activity from "../components/activity-list";

export default {
	name: "portal",

	components: {
		[Swipe.name]: Swipe,
		[SwipeItem.name]: SwipeItem,
		[Header.name]: Header,
		professional: professional,
		single: single,
		activity: activity
	},
	computed: {
		singleCourse() {
			const c = this.$store.state.single_course;
			return c;
		},
		upaid_order() {
			return this.$store.state.unpaid && this.$store.state.unpaid.length;
		},
		proCourse() {
			const c = this.$store.state.professional_course;
			return c;
		},
		activity() {
			const c = this.$store.state.activity;
			return c;
		},
		...mapState(["sliders"])
	},
	beforeMount() {
		if (this.$store.state.courses.count) {
			return;
		}
		this.$store.dispatch("GET_SLIDERS");
		this.$store.dispatch("GET_PROFESSIONAL_COURSE");
		this.$store.dispatch("GET_SINGLE_COURSE");
		this.$store.dispatch("GET_ACTIVITY");
		if (!this.$store.state.unpaid || !this.$store.state.unpaid.length) {
			this.$store.dispatch("GET_UNPAID_ORDERS");
		}
	},
	methods: {
		search: function () {
			location.href = "kkb://search/";
		}
	},
	head: {
		title: {
			inner: "首页"
		}
	}

};
</script>