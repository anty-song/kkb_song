<template>
    <div class="classwork">
        <section class="flex task-content classwork ">
            <ul id="tasklist" style="left:0%;width:100%">
                <li class="slide" index="" answer="" type="">
                    <h2 class="des hairlines">
                        <span class="iblock tag">
                            <span class="iblock text">
                                {{type}}
                            </span>
                        </span>
                        <span> {{ exerciseProblem.question}}</span>
                    </h2>
                    <ul class="option-box">
                        <li ref="reference" v-if="type=='单选'" v-for="(option,index) in exerciseProblem.options" v-on:click="flag &&radio(option.option,$event,index)" v-bind:class="{ 'active' : chooseArr[index], 'falseColor':chooseState[index]!=undefined&&!chooseState[index],'trueColor':chooseState[index],checkbox:type=='多选'}" class="item checkbox">
    
                            <span class="label">
                                <span class="iblock text">{{option.option}}</span>
                            </span>
                            <span class="tit">{{option.content}}</span>
                        </li>
                        <li ref="reference" v-if="type=='判断'" v-for="(option,index) in exerciseProblem.options" v-on:click="flag &&radio(option.option,$event,index)" v-bind:class="{ 'active' : chooseArr[index], 'falseColor':chooseState[index]!=undefined&&!chooseState[index],'trueColor':chooseState[index],checkbox:type=='多选'}" class="item checkbox">
    
                            <span class="label">
                                <span class="iblock text">{{option.option}}</span>
                            </span>
                            <span class="tit">{{option.content}}</span>
                        </li>
                        <li v-if="type=='多选'" v-for="(option,index) in exerciseProblem.options" v-on:click="flag&&checkbox(option.option,$event,index)" v-bind:class="{ 'active' : chooseArr[index], 'falseColor':chooseState[index]!=undefined&&!chooseState[index],'trueColor':chooseState[index],checkbox:type=='多选'}" class="item">
    
                            <span class="label">
                                <span class="iblock text">{{option.option}}</span>
                            </span>
                            <span class="tit">{{option.content}}</span>
                        </li>
                    </ul>
                    <div v-show="type=='多选'" v-on:click="!trueBtn&&flag&&check()" class="btn-box">
                        <button v-bind:class="{'disabled': trueBtn}" class="btn">确定</button>
                    </div>
                </li>
            </ul>
        </section>
        <footer id="bottomNav" class="hairlines">
            <span id="currentNo">{{(page+1)>allPage?allPage:(page+1)}}</span>/
            <span id="total">{{allPage}}</span>
        </footer>
        <section v-show="result" class="result">
            {{result}}
            <div class="market"></div>
            <div class="content">
                <div class="inner">
                    <!-- 全部正确 -->
                    <div v-show="rsSuccess" id="rs-success" class="summary">
                        <img class="pic" src="/public/images/img_stwork_note_true@3x.png">
                    </div>
                    <!-- 全部错误 -->
                    <div v-show="rsError" id="rs-error" class="summary">
                        <img class="pic" src="/public/images/img_stwork_note_flase@3x.png">
                    </div>
                    <!-- 有对有错显示头部 -->
                    <div v-show="rsPartial" id="rs-partial" class="summary">
                        <img class="pic" src="/public/images/img_stwork_note_nl@3x.png">
                        <div class="describe">
                            <p>答对：
                                <span id="rs-truenum">{{rightNum}}</span>题</p>
                            <p>答错：
                                <span id="rs-falsenum">{{wrongNum}}</span>题</p>
                        </div>
                    </div>
                    <div class="opt-box">
                        <a class="iblock opt" href="kkb://goback">好的,我知道了</a>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>
<style>
#app {
    width: 100% !important;
    height: 100%;
}

.task-content {
    overflow-y: auto;
    overflow-x: hidden;
}

.flex {
    -webkit-box-flex: 1;
    box-flex: 1;
    -ms-flex: 1;
    flex: 1;
    overflow: hidden;
}

.task-content ul {
    position: relative;
    overflow: hidden;
}

.task-content .slide {
    float: left;
    width: 100%;
}

.task-content .des {
    position: relative;
    padding: 0.3rem;
    font-size: 0.28rem;
    line-height: 1.42857;
    font-weight: normal;
    color: #3F3939;
    border-top: 1px solid #D0CACA;
}

.classwork .des .tag {
    position: relative;
    top: -2px;
    margin-right: 0.1rem;
    padding: 0px 0.08rem;
    height: 0.32rem;
    border: 1px solid #FF5B66;
    font-size: 0;
    line-height: 0.32rem;
    color: #FF5B66;
    border-radius: 8px;
    text-align: center;
}

.classwork .des .tag .text {
    width: 0.62rem;
    height: 0.32rem;
    font-size: 0.22rem;
    line-height: 0.32rem;
    color: #FF5B66;
}

.iblock {
    display: inline-block;
}

.classwork .option-box {
    padding-top: 2px;
    background-repeat: repeat-x;
    background-position: left top;
    background-color: #FFFFFF;
    background-size: 1px 1px;
}

.task-content ul {
    position: relative;
    overflow: hidden;
}

.classwork .option-box .item,
.classwork .option-box .item:active {
    position: relative;
    z-index: 22;
    padding: 0.32rem 0.3rem 0.32rem 0.82rem;
    font-size: 0px;
    background-repeat: repeat-x;
    background-position: left bottom;
    background-color: #FFFFFF;
    background-size: 1px 1px;
    -webkit-tap-highlight-color: rgba(255, 255, 255, 0);
    -moz-tap-highlight-color: rgba(255, 255, 255, 0);
    -o-tap-highlight-color: rgba(255, 255, 255, 0);
    -ms-tap-highlight-color: rgba(255, 255, 255, 0);
}

.classwork .option-box .label {
    display: block;
    position: absolute;
    top: 0.35rem;
    left: 0.3rem;
    width: 0.34rem;
    height: 0.34rem;
    border: 1px solid #CDC7C7;
    text-align: center;
    font-size: 0rem;
    line-height: 0.34rem;
    border-radius: 100%;
}

.classwork .option-box .label .text {
    height: 0.34rem;
    font-size: 0.24rem;
    color: #B8B1B2;
    font-weight: normal;
    line-height: 0.34rem;
}

.hairlines:after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 200%;
    height: 200%;
    -webkit-transform: scale(0.5);
    -ms-transform: scale(0.5);
    transform: scale(0.5);
    -webkit-transform-origin: left top;
    -ms-transform-origin: left top;
    transform-origin: left top;
}

.option-box .item.active {
    background: #F5F5F5;
}

.option-box .item.active .label {
    background: #FF5B66;
    border: 1px solid #FF5B66;
    color: #FFFFFF;
}


.option-box .item.trueColor .label {
    background: #00AAE5;
    border: 1px solid #5FD9A6;
    color: #FFFFFF;
}

.option-box .item.checkbox.active .label {
    background: #CDC7C7;
    border: 1px solid #CDC7C7;
    color: #FFFFFF;
}

.option-box .item.trueColor.checkbox .label {
    background: #00AAE5;
    border: 1px solid #5FD9A6;
    color: #FFFFFF;
}

.option-box .item.active.falseColor.checkbox .label {
    background: #FF5B66;
    border: 1px solid #FF5B66;
    color: #FFFFFF;
}

.option-box .item.trueColor .label .text {
    color: #FFFFFF;
}

.classwork .option-box .tit {
    font-size: 0.26rem;
    color: #706969;
}



/* footer */

.classwork>footer {
    height: 1rem;
    width: 100%;
    padding: 0.32rem 0px;
    font-size: 0.28rem;
    line-height: 1.28571;
    border-top: 1px solid #CDC7C7;
    text-align: center;
    color: #706969;
    position: fixed;
    border-bottom: 0;
    bottom: 0rem;
    left: 0;
}

.hairlines {
    position: relative;
    border: none !important;
}

.hairlines:after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 200%;
    height: 200%;
    -webkit-transform: scale(0.5);
    -ms-transform: scale(0.5);
    transform: scale(0.5);
    -webkit-transform-origin: left top;
    -ms-transform-origin: left top;
    transform-origin: left top;
}
</style>

<script>
import { router } from "../../router";
import store from "../../vuex/store";
import Vue from 'vue';
import { post as api } from "../../api";

export default {
    data: function () {
        return {
            exerciseProblem: null,//单个题目数据
            exerciseProblemArr: null,//课程的所有题目
            type: "null",//单选，多选，判断
            falseChoose: false,//选择错了
            trueChoose: false,//选择对了
            flag: true,//是否可以点击
            answer: null,//正确答案
            isChoose: false,//是否选择了
            chooseArr: [],//选择了哪些选项
            chooseAnswer: [],//选择的答案
            trueBtn: true,//确认按钮的显示隐藏
            allOption: [],//所有的选项
            chooseState: [],//是否选择正确了
            page: 0,//当前页
            allPage: null,//所有的页数
            rightNum: 0,//答对了几题
            rsSuccess: false,//全部正确的显示隐藏
            rsError: false,//全部错误的显示隐藏
            rsPartial: false,//有对有错的显示隐藏
            result: false,//结果的模态窗的宣誓隐藏
            allAnswer: [],//所有题目的答案
        };
    },
    beforeMount() {
        var that = this;
        this.$store.dispatch("GET_COURSE_EXERCISE", {
            courseid: this.$route.params.id,
            nodeid: this.$route.query.nodeid,
            token: this.$route.query.token
        }).then(() => {
            this.exerciseProblemArr = that.$store.state.exercise.data;
            this.exerciseProblem = this.exerciseProblemArr[0];
            this.answer = this.exerciseProblemArr[0].answer;
            this.allPage = this.exerciseProblemArr.length;
            switch (this.exerciseProblemArr[0].type) {
                case 1:
                    this.type = '单选'; break;
                case 2:
                    this.type = '多选'; break;
                case 3:
                    this.type = '判断'; break;
            }
        })
    },
    computed: {
        wrongNum() {
            var c = this.allPage - this.rightNum;
            return c;
        }
    },
    methods: {
        radio(option, $event, index) {
            this.checkbox(option, $event, index);
            this.check();
        },
        //多选题
        checkbox(option, $event, index) {
            var chooseNum = 0;
            this.trueBtn = true;
            Vue.set(this.chooseArr, index, !!!this.chooseArr[index]);
            this.selfAnswer(index, option, this.page);
            for (var i = 0; i < this.chooseArr.length; i++) {
                if (this.chooseArr[i] == true) { chooseNum++; }
            }
            if (chooseNum > 1) { this.trueBtn = false; }
        },
        // 自己选择的答案；
        selfAnswer(index, option, page) {
            let optionArr = this.exerciseProblemArr[page].options,
                lenOption = optionArr.length;
            let len = this.chooseArr.length;
            for (var i = 0; i < lenOption; i++) {
                if (this.chooseArr[i]) {
                    this.chooseAnswer[i] = optionArr[i].option;
                } else {
                    this.chooseAnswer[i] = false;
                }
                this.allOption[i] = optionArr[i].option;
            }
        },
        // 检查对错，标记每道题的状态
        check() {
            this.flag = false;
            var that = this;
            var index = 0;
            var selfAnswer = [];
            var len = this.exerciseProblemArr.length;
            var arr = this.answer.split('');
            for (var i = 0; i < this.allOption.length; i++) {
                 this.chooseState[i] = false;
                for (var j = 0; j < arr.length; j++) {
                    if (this.allOption[i] == arr[j]) {
                        Vue.set(this.chooseState, i, true);
                    }
                }
            }
            console.log(arr)
            console.log(this.chooseState)
            for (var i = 0; i < this.chooseAnswer.length; i++) {
                if (this.chooseAnswer[i]) {
                    selfAnswer.push(this.chooseAnswer[i])
                }
            }
            this.allAnswer.push(selfAnswer.join(''))
            if (selfAnswer.join('') == this.answer) {
                this.rightNum++
            }
            setTimeout(function () {
                return that.PageInit()
            }, 2000)
        },
        //每个页面的初始化
        PageInit() {
            this.flag = true;
            var len = this.exerciseProblemArr.length;
            var page = this.page++   
            var page = page + 1;
            this.falseChoose = false;
            this.trueChoose = false;

            this.isChoose = false;
            this.trueBtn = true;
            this.chooseArr = [];
            this.chooseState = [];
            if (len == page || len == 1) {
                this.page = len;
                this.result = true;
                this.flag = false;
                if (this.rightNum == page + 1) {
                    this.rsSuccess = true;
                }
                if (page - this.rightNum == page) {
                    this.rsError = true;
                } else {
                    this.rsPartial = true;
                }
                this.submitAnswer()
                return;
            }
            this.exerciseProblem = this.exerciseProblemArr[page]
            this.answer = this.exerciseProblemArr[page].answer;
            this.exerciseProblem = this.exerciseProblemArr[page]
            this.answer = this.exerciseProblemArr[page].answer;
            switch (this.exerciseProblemArr[page].type) {
                case 1:
                    this.type = '单选'; break;
                case 2:
                    this.type = '多选'; break;
                case 3:
                    this.type = '判断'; break;
            }
        },
        //提交数据
        submitAnswer() {
            api('/api/study/' + this.$route.params.id + '/exercise',{
                "answers": {
                    nodeid: this.$route.query.nodeid,
                    answer: this.allAnswer
                }
            }       
        , {
                    "X-Auth-Token": this.$route.query.token
                }).then((res) => {
                    console.log(res);
                })
        }
    },
    mounted: function () {

    }
};

</script>