import Exercise from "./exercise.vue";

export {
    Exercise
};