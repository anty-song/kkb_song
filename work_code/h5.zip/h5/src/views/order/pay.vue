<template>
	<div class="pay-order">
		<mt-header title="付款"></mt-header>
		<div class="panel padding table-panel order-info">
			<table>
				<tr>
					<td class="thead">订单名称</td>
					<td class="text-right">{{ order.name }}</td>
				</tr>
				<tr>
					<td class="thead">订单编号</td>
					<td class="text-right">{{ order.kid | orderId}}</td>
				</tr>
				<tr>
					<td class="thead">订单金额</td>
					<td class="text-right">
						<p class="red">￥{{ order.amount }}</p>
						<p class="small" v-if="order.cp_price">已优惠￥{{ order.cp_price }}</p>
					</td>
				</tr>
			</table>
		</div>

		<div class="pay-methods">
			<form method="POST">
				<div class="field-wrapper">
					<h4>请选择支付方式</h4>
					<div class="radio-item" :class="{ checked: channel == 'alipay_wap' }" >
						<label for="alipay">
							<img class="icon" src="/img/signup/ic_pay_zfb@3x.png" alt="支付宝">
							<div class="radio-label">
								<p>支付宝支付</p>
								<p class="small">推荐有支付宝帐号用户使用</p>
							</div>
							<input id="alipay" type="radio" name="channel" value="alipay_wap" v-model="channel">
						</label>
					</div>
				</div>

				<div class="btn-wrapper">
					<mt-button type="danger" @click.native.prevent="do_pay()" class="btn-block">
						立即支付
					</mt-button>
				</div>
			</form>
		</div>
	</div>
</template>

<style lang="scss">
	@import "../../assets/sass/variables.scss";

	.pay-order {
		.order-info {
			margin-top: 0.2rem;

			.small {
				font-size: 0.25rem;
				color: $light-gray;
			}
		}
	}

	.pay-methods {
		color: $dark;
		margin-top: 0.2rem;

		.field-wrapper {
			background-color: #fff;
			padding: 0 0.3rem;
		}

		h4 {
			font-size: 0.28rem;
			padding: 0.24rem 0;
		}

		.btn-wrapper {
			padding: 0 0.3rem;
		}

		button {
			font-size: 0.28rem;
			margin-top: 0.3rem;
			height: 0.85rem;
		}
	}
</style>

<script>
	import { Header } from "mint-ui";
	import store from "../../vuex/store";
	import { get } from "../../api";
	import { payOrder } from "../../lib/orders";
	import { router } from "../../router";
	import { Toast as toast } from "mint-ui";
	import { orderStatus } from "../../utils";

	export default {
		name: "Pay",
		components: {
			[Header.name]: Header
		},
		data () {
			return {
				order_id: this.$route.params.id,
				channel: "alipay_wap",
			};
		},
		beforeMount () {
			// 判断订单是否已经支付，获取订单信息
			store.dispatch("GET_ORDER_INFO", this.$route.params.id)
				.then((data) => {
					if (!this.$store.state.order.kid) {
						toast("该订单号无效");
						router.push({ name: "home" });
					}

					if (data && data.status === "已完成") {
						toast("该订单号已支付");
						router.push({ name: "home" });
					}
				});
			get("/open/order/get?thirdOrderNo=" + this.$route.params.id)
				.then(({ data, status }) => {
					// 根据支付状态跳转
					if (data && orderStatus(data.status) >= 30) {
						toast("该订单已支付");
						router.push({ name: "home" });
					}
				});
		},
		computed: {
			order () {
				return store.state.order;
			}
		},
		methods: {
			do_pay () {
				payOrder(this.channel);
			}
		}
	};
</script>