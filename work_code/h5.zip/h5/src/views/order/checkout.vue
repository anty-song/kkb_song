<template>
	<div class="checkout-wrapper">
		<mt-header title="确认信息"></mt-header>
		<div class="panel padding table-panel info-confirm">
			<table class="stu-info">
				<tr>
					<td class="thead">姓名</td>
					<td>{{ user.trueName }}</td>
				</tr>
				<tr>
					<td class="thead">QQ</td>
					<td>{{ user.qq }}</td>
				</tr>
			</table>
		</div>

		<div class="panel padding course clearfix">
			<img :src="info.pic" alt="" class="pull-left">
			<div class="">
				<p>{{ info.name }}-就业班</p>
				<p>￥{{ info.occupy_price_spec }}</p>
			</div>
		</div>

		<div class="panel coupon-code">
			<mt-field label="优惠码" placeholder="输入优惠码" class="mt-text-right" 
			v-model.trim="couponcode"></mt-field>
		</div>

		<div class="panel padding spec-price">
			<span>商品金额</span>
			<span class="pull-right red">￥{{ info.occupy_price_spec }}</span>
		</div>

		<div class="bottom-bar">
			<span class="final-price">实付款：<span class="red">￥{{ final_price | fixed }}</span></span>
			<a @click="order()" class="pay">去付款</a>
		</div>
	</div>
</template>

<style lang="scss" scoped>
	@import "../../assets/sass/variables.scss";

	.mint-cell:before, .mint-cell:after {
		border-color: transparent;
	}
	
	.checkout-wrapper {
		color: $dark;
		width: inherit;
	}

	.panel {
		background-color: #fff;
		margin-top: 0.2rem;
	}
	.course {
		padding-top: 0.2rem;
		padding-bottom: 0.2rem;

		img {
			width: 1.9rem;
			margin-right: 0.2rem;
		}

		p {
			line-height: 0.42rem;
			font-size: 0.28rem;
		}

		p:first-child {
			margin-bottom: 0.25rem;
		}
	}

	.coupon-code {
		padding: 0 0.3rem;
		font-size: 0.28rem;
	}

	.spec-price {
		padding: 0.21rem 0.3rem;
		font-size: 0.28rem;
	}

	.bottom-bar {
		position: fixed;
		bottom: 0;
		width: inherit;
		background-color: #fff;
		line-height: 0.9rem;

		.final-price {
			padding-left: 0.3rem;
		}

		.pay {
			float: right;
			display: inline-block;
			line-height: 0.9rem;
			background-color: $red;
			color: #fff;
			width: 2.6rem;
			text-align: center;
		}
	}
</style>

<style lang="scss">
	.coupon-code {
		input {
			height: 0.84rem;
		}
	}
</style>

<script>
	import { Header, Field, Toast } from "mint-ui";
	import { post as api } from "../../api";
	import { createOrder } from "../../lib/orders";
	import { router } from "../../router";
	import debounce from "lodash/debounce";
	import store from "../../vuex/store";

	export default {
		name: "Checkout",
		components: {
			[Header.name]: Header,
			[Field.name]: Field
		},
		data () {
			return {
				off_price: 0,
				couponcode: ""
			};
		},
		beforeRouteEnter (to, from, next) {
			const user = store.state.user;
			const signupStatus = store.state.current.signup_status;
			if (!Object.keys(signupStatus).length) {
				store.dispatch("GET_USER_SIGNUP_STATUS", {
					uid: user.uid,
					course_id: to.params.id
				}).then(() => next());
				return;
			}

			next();
		},
		beforeMount () {
			this.$store.dispatch("GET_COURSE_INFO", this.$route.params.id);
		},
		computed: {
			info () {
				return this.$store.state.current.info;
			},
			user () {
				return this.$store.state.current.signup_status;
			},
			final_price () {
				return Number(this.$store.state.current.info.occupy_price_spec) - Number(this.off_price);
			}
		},
		watch: {
			couponcode () {
				this.getOffPrice();
			}
		},
		methods: {
			getOffPrice: debounce(function () {
				if (this.couponcode.length !== 8) {
					this.off_price = 0;
					return;
				}
				api("/api/accounting/" + this.$route.params.id + "/check", {
					couponcode: this.couponcode
				}).then((res) => {
					this.off_price = 0;
					switch (res.error_code) {
						case 0:
							var data = res.data || {};
							this.off_price = data.money || 0;
							break;
						case 54001:
							Toast({
								message: "优惠码无效"
							});
							break;
						case 54002:
							Toast("优惠码已被使用");
							break;
						case 54003:
							Toast("优惠码过期");
							break;
					}
					if (res.error_code !== 0) {
						this.couponcode = "";
					}
				});
			}, 1000),
			order () {
				createOrder({
					c_id: this.$route.params.id,
					c_type: 1,
					cp_code: this.couponcode
				})
				.then((order) => {
					router.push({ name: "pay", params: { id: order.o_id }});
				}, (error) => {
					if (!PRODUCTION) {
						console.log("error: ", error);
					}
				});
			}
		}
	};
</script>