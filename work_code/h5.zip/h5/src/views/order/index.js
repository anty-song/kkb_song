import Checkout from "./checkout.vue";
import Pay from "./pay.vue";

export {
	Checkout,
	Pay
};
