/**
 * 路由入口配置
 */
import Vue from "vue";
import Router from "vue-router";
import portal from "./views/portal.vue";
import community from "./views/community/community.vue";
import activityDetail from "./views/community/activityDetail.vue";
import articleDetail from "./views/community/articleDetail.vue";
import auditoriumDetail from "./views/community/auditoriumDetail.vue";
import Exercise from "./views/exercise/exercise.vue";
import Orders from "./views/orders.vue";
import { Course, courseDetail, Section, Signup, Result } from "./views/course";
import { Checkout, Pay } from "./views/order";
import { Toast as toast } from "mint-ui";
import store from "./vuex/store";
import cookie from "./lib/cookie";

export const routerConfig = {
    routes: [
        { path: "/portal", component: portal, name: "portal" },
        { path: "/community/:id", component: community, name: "community" },
        { path: "/activity/:id", component: activityDetail, name: "activity" },
        { path: "/article/:id", component: articleDetail, name: "article" },
        { path: "/auditorium/:id", component: auditoriumDetail, name: "auditorium" },
        { path: "/course/:id", component: Course, name: "course" },
        { path: "/courseDetail/:id", component: courseDetail, name: "courseDetail" },
        {
            path: "/alert",
            component: Result,
            name: "alert",
            meta: {
                auth: true,
                token: true
            }
        },
        {
            path: "/orders",
            component: Orders,
            name: "orders",
            meta: {
                auth: true,
                token: true
            }
        },
        { path: "/exercise/:id", component: Exercise, name: "exercise" },
        {
            path: "/order/checkout/:id",
            component: Checkout,
            name: "checkout",
            meta: {
                auth: true,
                token: true
            }
        },
        {
            path: "/order/pay/:id",
            component: Pay,
            name: "pay",
            meta: {
                auth: true,
                token: true
            }
        },
        { path: "/section/:course/:section", component: Section, name: "section" },
        {
            path: "/signup/:course",
            component: Signup,
            name: "signup",
            meta: {
                auth: true
            }
        },
        { path: "*", redirect: "/portal" }
    ],
    scrollBehavior(to, from, savedPosition) {
        return { x: 0, y: 0 };
    },
    mode: "history"
};

/**
 * 路由属性配置
 */
Vue.use(Router);
export const router = new Router(routerConfig);
// openid 检查
router.beforeEach((to, from, next) => {
    const openId = to.query.openid || store.state.user.openid || cookie.get("openid");
    openId ? cookie.set("openid", openId) : 1;
    if (to.matched.some(record => record.meta.auth) && !openId) {
        toast({ message: "请先登录高校邦", duration: 5000 });
        if (!from.name) {
            next("/");
        }
        return;
    }

    next();
});

// 用户 token 检查 openid 必须存在
router.beforeEach((to, from, next) => {
    const user = store.state.user;
    const openId = user.openid || cookie.get("openid");

    function process() {
        if (to.matched.some(record => record.meta.token)) {
            if (store.state.user.token) {
                next();
            } else {
                !from.name ? next("/") : 1;
            }
            return;
        }

        next();
    }

    if (!user.uid && user.pending !== "resolved") {
        store.dispatch("GET_USER_INFO", openId)
            .then(() => {
                process();
            }, () => {
                process();
            });
    } else {
        process();
    }
});