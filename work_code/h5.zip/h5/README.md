开课吧 H5 项目

规范参考
https://github.com/airbnb/javascript

全局依赖
	
	nodejs
	pm2


开发

```
// 全局 安装 nodemon
npm i nodemon babel-node -g

// 依赖安装
npm run dep

// 包含 node 后端
npm run server   
// 或者 纯前端 
npm run dev

```


线上运行
```
npm run dep
pm2 server.json --env=production
```
